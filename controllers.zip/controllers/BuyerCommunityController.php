<?php

class BuyerCommunityController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','verifytheavailabilityofthiscode','getTheDetailsAboutThisCommunity','getTheSlotOrderDetails',
                                    'getTheSlotOrderDeliveryDetails','getTheCommunityPaymmentSummaryDetails'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','createnewcommunity','modifycommunity','deleteonecommunity','listAllCommunityCreatedByMerchant',
                                    'recreatefromanothercommunity'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        /**
         * This is the function that  creates a new community
         */
        public function actioncreatenewcommunity(){
            $model = new BuyerCommunity;
            
            $user_id = Yii::app()->user->id;
            
            $merchant_id = $this->getTheMerchantIdOfThisUser($user_id);
            
            $model->name = $_REQUEST['name'];
            if(isset($_REQUEST['description'])){
                $model->description = $_REQUEST['description'];
            }
            $model->code  = $model->generateTheCodeForThisCommunity($merchant_id);
           
            $model->slot_id = $_REQUEST['slot_id'];
            $model->delivery_preference = $_REQUEST['delivery_preference'];
            if(isset($_REQUEST['address_of_centralized_delivery'])){
                $model->address_of_centralized_delivery = $_REQUEST['address_of_centralized_delivery'];
            }
            if(isset($_REQUEST['place_id'])){
                $model->place_id = $_REQUEST['place_id'];
            }
             if(isset($_REQUEST['city_of_delivery'])){
                $model->city_of_delivery = $_REQUEST['city_of_delivery'];
            }
             if(isset($_REQUEST['state_of_delivery'])){
                $model->state_of_delivery = $_REQUEST['state_of_delivery'];
            }
            if(isset($_REQUEST['status'])){
                $model->status = $_REQUEST['status'];
            }
            if(isset($_REQUEST['minimum_purchase_per_member'])){
                $model->minimum_purchase_per_member = $_REQUEST['minimum_purchase_per_member'];
            }
            if(isset($_REQUEST['estimated_minimum_number_of_members_required'])){
                $model->estimated_minimum_number_of_members_required = $_REQUEST['estimated_minimum_number_of_members_required'];
            }
            if(isset($_REQUEST['minimum_purchases_required_before_activation'])){
                $model->minimum_purchases_required_before_activation = $_REQUEST['minimum_purchases_required_before_activation'];
            }
             if(isset($_REQUEST['date_of_activation'])){
                $model->date_of_activation = date("Y-m-d H:i:s", strtotime($_REQUEST['date_of_activation']));
            }
             if(isset($_REQUEST['start_date_of_delivery'])){
                $model->start_date_of_delivery = date("Y-m-d H:i:s", strtotime($_REQUEST['start_date_of_delivery']));
            }
            if(isset($_REQUEST['last_date_of_delivery'])){
                $model->last_date_of_delivery = date("Y-m-d H:i:s", strtotime($_REQUEST['last_date_of_delivery']));
            }
            if(isset($_REQUEST['delivery_cost_per_slot'])){
                $model->delivery_cost_per_slot = $_REQUEST['delivery_cost_per_slot'];
            }
             if(isset($_REQUEST['cost_per_slot'])){
                $model->cost_per_slot = $_REQUEST['cost_per_slot'];
            }
            if(isset($_REQUEST['terms_and_condition'])){
                $model->terms_and_condition = $_REQUEST['terms_and_condition'];
            }
             if(isset($_REQUEST['last_date_of_membership_enrollment'])){
                $model->last_date_of_membership_enrollment = date("Y-m-d H:i:s", strtotime($_REQUEST['last_date_of_membership_enrollment']));
            }
            if(isset($_REQUEST['payment_terms'])){
                $model->payment_terms = $_REQUEST['payment_terms'];
            }
            if(isset($_REQUEST['preferred_hybrid_payment'])){
                $model->preferred_hybrid_payment = $_REQUEST['preferred_hybrid_payment'];
            }
            if(isset($_REQUEST['hybrid_payment_must_exclude'])){
                $model->hybrid_payment_must_exclude = $_REQUEST['hybrid_payment_must_exclude'];
            }
            if(isset($_REQUEST['restrict_membership_to'])){
                $model->restrict_membership_to = $_REQUEST['restrict_membership_to'];
            }
            $model->merchant_id = $merchant_id;
            $model->type = $_REQUEST['type'];
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
             if($model->save()){
               header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => "This community is created successfully")
                           );
                
            }else{
                 header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => "Validation issue: This community was not created")
                           );
            }
        }
        
        /**
         * This is the function that modifies community info
         */
        public function actionmodifycommunity(){
            
             $_id = $_REQUEST['id'];
            $model=  BuyerCommunity::model()->findByPk($_id);
            
            $model->name = $_REQUEST['name'];
            if(isset($_REQUEST['description'])){
                $model->description = $_REQUEST['description'];
            }
            $model->code  = $_REQUEST['code'];
            $model->slot_id = $_REQUEST['slot_id'];
            $model->delivery_preference = $_REQUEST['delivery_preference'];
            if(isset($_REQUEST['address_of_centralized_delivery'])){
                $model->address_of_centralized_delivery = $_REQUEST['address_of_centralized_delivery'];
            }
            if(isset($_REQUEST['place_id'])){
                $model->place_id = $_REQUEST['place_id'];
            }
             if(isset($_REQUEST['city_of_delivery'])){
                $model->city_of_delivery = $_REQUEST['city_of_delivery'];
            }
             if(isset($_REQUEST['state_of_delivery'])){
                $model->state_of_delivery = $_REQUEST['state_of_delivery'];
            }
            if(isset($_REQUEST['status'])){
                $model->status = $_REQUEST['status'];
            }
            if(isset($_REQUEST['minimum_purchase_per_member'])){
                $model->minimum_purchase_per_member = $_REQUEST['minimum_purchase_per_member'];
            }
            if(isset($_REQUEST['estimated_minimum_number_of_members_required'])){
                $model->estimated_minimum_number_of_members_required = $_REQUEST['estimated_minimum_number_of_members_required'];
            }
            if(isset($_REQUEST['minimum_purchases_required_before_activation'])){
                $model->minimum_purchases_required_before_activation = $_REQUEST['minimum_purchases_required_before_activation'];
            }
             if(isset($_REQUEST['date_of_activation'])){
                $model->date_of_activation = date("Y-m-d H:i:s", strtotime($_REQUEST['date_of_activation']));
            }
             if(isset($_REQUEST['start_date_of_delivery'])){
                $model->start_date_of_delivery = date("Y-m-d H:i:s", strtotime($_REQUEST['start_date_of_delivery']));
            }
            if(isset($_REQUEST['last_date_of_delivery'])){
                $model->last_date_of_delivery = date("Y-m-d H:i:s", strtotime($_REQUEST['last_date_of_delivery']));
            }
            if(isset($_REQUEST['delivery_cost_per_slot'])){
                $model->delivery_cost_per_slot = $_REQUEST['delivery_cost_per_slot'];
            }
             if(isset($_REQUEST['cost_per_slot'])){
                $model->cost_per_slot = $_REQUEST['cost_per_slot'];
            }
            if(isset($_REQUEST['terms_and_condition'])){
                $model->terms_and_condition = $_REQUEST['terms_and_condition'];
            }
             if(isset($_REQUEST['last_date_of_membership_enrollment'])){
                $model->last_date_of_membership_enrollment = date("Y-m-d H:i:s", strtotime($_REQUEST['last_date_of_membership_enrollment']));
            }
            if(isset($_REQUEST['payment_terms'])){
                $model->payment_terms = $_REQUEST['payment_terms'];
            }
            if(isset($_REQUEST['preferred_hybrid_payment'])){
                $model->preferred_hybrid_payment = $_REQUEST['preferred_hybrid_payment'];
            }
            if(isset($_REQUEST['hybrid_payment_must_exclude'])){
                $model->hybrid_payment_must_exclude = $_REQUEST['hybrid_payment_must_exclude'];
            }
            if(isset($_REQUEST['restrict_membership_to'])){
                $model->restrict_membership_to = $_REQUEST['restrict_membership_to'];
            }
             if(isset($_REQUEST['merchant_id'])){
                $model->merchant_id = $_REQUEST['merchant_id'];
            }
            $model->type = $_REQUEST['type'];
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
             if($model->save()){
               header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => "This community is updated successfully")
                           );
                
            }else{
                 header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => "Validation issue: This community was not updated")
                           );
            }
        }
        
        
        /**
         * This is the function that deletes one community
         */
        public function actiondeleteonecommunity(){
            $_id = $_REQUEST['id'];
            $model=  BuyerCommunity::model()->findByPk($_id);
           
            
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' community was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
        }
        
        
        /**
         * This is the function to list all commnities that belongs to a merchant
         */
        public function actionlistAllCommunityCreatedByMerchant(){
            
            $model = new User;
            $user_id = Yii::app()->user->id;
            
            $merchant_id = $model->getTheMerchantIdOfThisUser($user_id);
            
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='merchant_id=:merid';
              $criteria->params = array(':merid'=>$merchant_id);
              $community= BuyerCommunity::model()->findAll($criteria);
              if($community===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "community" => $community,
                                   
                    
                            ));
                       
                       
                }
        }
        
        
        /**
         * This is the function that recreates a community from an existing one
         */
        public function actionrecreatefromanothercommunity(){
            
            $model = new BuyerCommunity;
            
            $model->name = $_REQUEST['name'];
            if(isset($_REQUEST['description'])){
                $model->description = $_REQUEST['description'];
            }
           $model->merchant_id = $_REQUEST['merchant_id'];
           $model->code  = $model->generateTheCodeForThisCommunity($model->merchant_id);
            
            $model->slot_id = $_REQUEST['slot_id'];
            $model->delivery_preference = $_REQUEST['delivery_preference'];
            if(isset($_REQUEST['address_of_centralized_delivery'])){
                $model->address_of_centralized_delivery = $_REQUEST['address_of_centralized_delivery'];
            }
            if(isset($_REQUEST['place_id'])){
                $model->place_id = $_REQUEST['place_id'];
            }
             if(isset($_REQUEST['city_of_delivery'])){
                $model->city_of_delivery = $_REQUEST['city_of_delivery'];
            }
             if(isset($_REQUEST['state_of_delivery'])){
                $model->state_of_delivery = $_REQUEST['state_of_delivery'];
            }
            if(isset($_REQUEST['status'])){
                $model->status = $_REQUEST['status'];
            }
            if(isset($_REQUEST['minimum_purchase_per_member'])){
                $model->minimum_purchase_per_member = $_REQUEST['minimum_purchase_per_member'];
            }
            if(isset($_REQUEST['estimated_minimum_number_of_members_required'])){
                $model->estimated_minimum_number_of_members_required = $_REQUEST['estimated_minimum_number_of_members_required'];
            }
            if(isset($_REQUEST['minimum_purchases_required_before_activation'])){
                $model->minimum_purchases_required_before_activation = $_REQUEST['minimum_purchases_required_before_activation'];
            }
             if(isset($_REQUEST['date_of_activation'])){
                $model->date_of_activation = date("Y-m-d H:i:s", strtotime($_REQUEST['date_of_activation']));
            }
             if(isset($_REQUEST['start_date_of_delivery'])){
                $model->start_date_of_delivery = date("Y-m-d H:i:s", strtotime($_REQUEST['start_date_of_delivery']));
            }
            if(isset($_REQUEST['last_date_of_delivery'])){
                $model->last_date_of_delivery = date("Y-m-d H:i:s", strtotime($_REQUEST['last_date_of_delivery']));
            }
            if(isset($_REQUEST['delivery_cost_per_slot'])){
                $model->delivery_cost_per_slot = $_REQUEST['delivery_cost_per_slot'];
            }
             if(isset($_REQUEST['cost_per_slot'])){
                $model->cost_per_slot = $_REQUEST['cost_per_slot'];
            }
            if(isset($_REQUEST['terms_and_condition'])){
                $model->terms_and_condition = $_REQUEST['terms_and_condition'];
            }
             if(isset($_REQUEST['last_date_of_membership_enrollment'])){
                $model->last_date_of_membership_enrollment = date("Y-m-d H:i:s", strtotime($_REQUEST['last_date_of_membership_enrollment']));
            }
            if(isset($_REQUEST['payment_terms'])){
                $model->payment_terms = $_REQUEST['payment_terms'];
            }
            if(isset($_REQUEST['preferred_hybrid_payment'])){
                $model->preferred_hybrid_payment = $_REQUEST['preferred_hybrid_payment'];
            }
            if(isset($_REQUEST['hybrid_payment_must_exclude'])){
                $model->hybrid_payment_must_exclude = $_REQUEST['hybrid_payment_must_exclude'];
            }
            if(isset($_REQUEST['restrict_membership_to'])){
                $model->restrict_membership_to = $_REQUEST['restrict_membership_to'];
            }
             $model->type = $_REQUEST['type'];          
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
             if($model->save()){
               header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => "This community is created successfully")
                           );
                
            }else{
                 header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => "Validation issue: This community was not created")
                           );
            }
            
            
            
        }
        
        /**
         * This is the function that retrieves a merchant id of a user
         */
        public function getTheMerchantIdOfThisUser($user_id){
            $model = new User;
            return $model->getTheMerchantIdOfThisUser($user_id);
        }
        
        
        
        /**
         * This is the function that verifies if a community code exist
         */
        public function actionverifytheavailabilityofthiscode(){
            $model =  new BuyerCommunity;
            $code = $_REQUEST['code'];
            
            if($model->isCodeExist($code)){
                $community_id = $model->getTheIdOfThisCommunityWithThisCode($code);
                $slot_id = $model->getTheSlotIdCurrentlyAttachedToThisCommunity($code);
                 $code_status = $model->getThisCodeStatus($code);
                if($model->isCodeExpired($code)==false){
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "is_code_exist"=>true,
                            "code"=>$code,
                            "is_code_expired"=>false,
                            "status"=>$code_status,
                            "community_id"=>$community_id,
                            "slot_id"=>$slot_id  
                           
                                
                        )); 
                    
                    
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"msg" =>"Expired Code: This code had expired and is no longer active"
                             "is_code_exist"=>true,
                            "code"=>$code,
                            "is_code_expired"=>true,
                            "status"=>$code_status,
                             "community_id"=>$community_id,
                             "slot_id"=>$slot_id      
                           
                        )); 
                    
                }
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"msg" =>"Sorry: This code does not exist. Please check the code and try again"
                            "is_code_exist"=>false,
                            "code"=>$code,
                            "is_code_expired"=>null,
                            "status"=>null,
                           "community_id"=>null,
                           "slot_id"=>null     
                           
                        ));
            }
            
            
        }
        
        
        /**
         * This is the function that retrieves the details of a community
         */
        public function actiongetTheDetailsAboutThisCommunity(){
            
            $id = $_REQUEST['community_id'];
            $model=  BuyerCommunity::model()->findByPk($id);
            
            //get the place of delivery
            if($model->delivery_preference == "within_a_place"){
                 $place_of_delivery = $this->getTheNameOfThePlace($model->place_id) . "," . " " . $this->getTheCityNameOfThisCity($model->city_of_delivery);
            }else if($model->delivery_preference == "centralized"){
                $place_of_delivery = $model->address_of_centralized_delivery . "," . " " .$this->getTheCityNameOfThisCity($model->city_of_delivery) . "," . " " . $this->getTheStateName($model->state_of_delivery);
            }else if($model->delivery_preference == "decentralized"){
                $place_of_delivery = "varies";
            }
           
            
             if($model===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "community" => $model,
                                    "price"=>number_format((double)$model->cost_per_slot, 2),
                                    "delivery_cost"=>number_format((double)$model->delivery_cost_per_slot, 2),
                                   "place_of_delivery"=>$place_of_delivery
                    
                            ));
                       
                       
                }
            
            
        }
        
        
        /**
         * This is the function that will get the name of a place
         */
        public function getTheNameOfThePlace($place_id){
            $model = new Place;
            return $model->getTheNameOfThePlace($place_id);
        }
        
        
        /**
         * This is the function that will get the name of a city
         */
        public function getTheCityNameOfThisCity($city_id){
            $model = new City;
            return $model->getTheNameOfThisCity($city_id);
        }
        
        /**
         * This is the function that gets the name of a state
         */
        public function getTheStateName($state_id){
            $model = new State;
            return $model->getTheStateName($state_id);
        }
        
        
        /**
         * This is the function that returns the slot purchase details from a community member
         */
        public function actiongetTheSlotOrderDetails(){
            
             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "community_id" => $_REQUEST['community_id'],
                                    "slot_id"=>$_REQUEST['slot_id'],
                                    "place_id"=>$_REQUEST['place_id'],
                                   "cost_per_slot"=>$_REQUEST['cost_per_slot'],
                                    "minimum_purchase_per_member"=>$_REQUEST['minimum_purchase_per_member'],
                                     "delivery_cost_per_slot"=>$_REQUEST['delivery_cost_per_slot'],
                                     "price_per_slot"=>$_REQUEST['price_per_slot'],
                                    "delivery_cost_formatted"=>$_REQUEST['delivery_cost_formatted'],
                                    "delivery_preference"=>$_REQUEST['delivery_preference'],
                                    "payment_terms"=>$_REQUEST['payment_terms'],
                                    "preferred_hybrid_payment"=>$_REQUEST['preferred_hybrid_payment'],
                                    "hybrid_payment_must_exclude"=>$_REQUEST['hybrid_payment_must_exclude'],
                    
                            ));
        }
        
        
         /**
         * This is the function that returns the slot purchase details from a community member
         */
        public function actiongetTheSlotOrderDeliveryDetails(){
            
            $id = $_REQUEST['community_id'];
            $model=  BuyerCommunity::model()->findByPk($id);
            
            //get the place of delivery
            if($model->delivery_preference == "within_a_place"){
                 $place_of_delivery = $this->getTheNameOfThePlace($model->place_id) . "," . " " . $this->getTheCityNameOfThisCity($model->city_of_delivery);
            }else if($model->delivery_preference == "centralized"){
                $place_of_delivery = $model->address_of_centralized_delivery . "," . " " .$this->getTheCityNameOfThisCity($model->city_of_delivery) . "," . " " . $this->getTheStateName($model->state_of_delivery);
            }else if($model->delivery_preference == "decentralized"){
                $place_of_delivery = "varies";
            }
            
             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "community_id" => $_REQUEST['community_id'],
                                    "slot_id"=>$_REQUEST['slot_id'],
                                    "place_id"=>$_REQUEST['place_id'],
                                   "cost_per_slot"=>$_REQUEST['cost_per_slot'],
                                     "delivery_cost_per_slot"=>$_REQUEST['delivery_cost_per_slot'],
                                     "delivery_preference"=>$_REQUEST['delivery_preference'],
                                    "payment_terms"=>$_REQUEST['payment_terms'],
                                    "preferred_hybrid_payment"=>$_REQUEST['preferred_hybrid_payment'],
                                    "hybrid_payment_must_exclude"=>$_REQUEST['hybrid_payment_must_exclude'],
                                    "place_of_delivery"=>$place_of_delivery,
                                    "ordered_quantity"=>$_REQUEST['ordered_quantity'],
                                    "total_cost"=>$_REQUEST['total_cost'],
                    
                            ));
        }
        
        
        
         /**
         * This is the function that returns the payment summary  details from a community member
         */
        public function actiongetTheCommunityPaymmentSummaryDetails(){
            
            $id = $_REQUEST['community_id'];
            $model=  BuyerCommunity::model()->findByPk($id);
            
            //get the place of delivery
            if($model->delivery_preference == "within_a_place"){
                 $place_of_delivery = $this->getTheNameOfThePlace($model->place_id) . "," . " " . $this->getTheCityNameOfThisCity($model->city_of_delivery);
            }else if($model->delivery_preference == "centralized"){
                $place_of_delivery = $model->address_of_centralized_delivery . "," . " " .$this->getTheCityNameOfThisCity($model->city_of_delivery) . "," . " " . $this->getTheStateName($model->state_of_delivery);
            }else if($model->delivery_preference == "decentralized"){
                $place_of_delivery = "varies";
            }
            
             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "cost_per_slot" => $_REQUEST['cost_per_slot'],
                                    "delivery_cost_per_slot"=>$_REQUEST['delivery_cost_per_slot'],
                                    "ordered_quantity"=>$_REQUEST['ordered_quantity'],
                                   "slot_id"=>$_REQUEST['slot_id'],
                                     "place_id"=>$_REQUEST['place_id'],
                                     "community_id"=>$_REQUEST['community_id'],
                                    "total_cost"=>$_REQUEST['total_cost'],
                                    "delivery_preference"=>$_REQUEST['delivery_preference'],
                                    "payment_terms"=>$_REQUEST['payment_terms'],
                                    "total_cost_of_delivery"=>$_REQUEST['total_cost_of_delivery'],
                                    "preferred_hybrid_payment"=>$_REQUEST['preferred_hybrid_payment'],
                                    "hybrid_payment_must_exclude"=>$_REQUEST['hybrid_payment_must_exclude'],
                                    "recipient_name"=>$_REQUEST['recipient_name'],
                                    "mobile_number"=>$_REQUEST['mobile_number'],
                                    "vary_place_of_delivery"=>$_REQUEST['vary_place_of_delivery'],
                                     "vary_quantity_required"=>$_REQUEST['vary_quantity_required'],
                                     "state_id"=>$_REQUEST['state_id'],
                                     "city_id"=>$_REQUEST['city_id'],
                                     "place_of_delivery"=>$_REQUEST['place_of_delivery'],
                    
                            ));
        }
}
