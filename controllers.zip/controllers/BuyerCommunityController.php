<?php

class BuyerCommunityController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','createnewcommunity','modifycommunity','deleteonecommunity','listAllCommunityCreatedByMerchant',
                                    'recreatefromanothercommunity'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        /**
         * This is the function that  creates a new community
         */
        public function actioncreatenewcommunity(){
            $model = new BuyerCommunity;
            
            $user_id = Yii::app()->user->id;
            
            $merchant_id = $this->getTheMerchantIdOfThisUser($user_id);
            
            $model->name = $_REQUEST['name'];
            if(isset($_REQUEST['description'])){
                $model->description = $_REQUEST['description'];
            }
            $model->code  = $model->generateTheCodeForThisCommunity($merchant_id);
           
            $model->slot_id = $_REQUEST['slot_id'];
            $model->delivery_preference = $_REQUEST['delivery_preference'];
            if(isset($_REQUEST['address_of_centralized_delivery'])){
                $model->address_of_centralized_delivery = $_REQUEST['address_of_centralized_delivery'];
            }
            if(isset($_REQUEST['place_id'])){
                $model->place_id = $_REQUEST['place_id'];
            }
             if(isset($_REQUEST['city_of_delivery'])){
                $model->city_of_delivery = $_REQUEST['city_of_delivery'];
            }
             if(isset($_REQUEST['state_of_delivery'])){
                $model->state_of_delivery = $_REQUEST['state_of_delivery'];
            }
            if(isset($_REQUEST['status'])){
                $model->status = $_REQUEST['status'];
            }
            if(isset($_REQUEST['minimum_purchase_per_member'])){
                $model->minimum_purchase_per_member = $_REQUEST['minimum_purchase_per_member'];
            }
            if(isset($_REQUEST['estimated_minimum_number_of_members_required'])){
                $model->estimated_minimum_number_of_members_required = $_REQUEST['estimated_minimum_number_of_members_required'];
            }
            if(isset($_REQUEST['minimum_purchases_required_before_activation'])){
                $model->minimum_purchases_required_before_activation = $_REQUEST['minimum_purchases_required_before_activation'];
            }
             if(isset($_REQUEST['date_of_activation'])){
                $model->date_of_activation = date("Y-m-d H:i:s", strtotime($_REQUEST['date_of_activation']));
            }
             if(isset($_REQUEST['start_date_of_delivery'])){
                $model->start_date_of_delivery = date("Y-m-d H:i:s", strtotime($_REQUEST['start_date_of_delivery']));
            }
            if(isset($_REQUEST['last_date_of_delivery'])){
                $model->last_date_of_delivery = date("Y-m-d H:i:s", strtotime($_REQUEST['last_date_of_delivery']));
            }
            if(isset($_REQUEST['delivery_cost_per_slot'])){
                $model->delivery_cost_per_slot = $_REQUEST['delivery_cost_per_slot'];
            }
             if(isset($_REQUEST['cost_per_slot'])){
                $model->cost_per_slot = $_REQUEST['cost_per_slot'];
            }
            if(isset($_REQUEST['terms_and_condition'])){
                $model->terms_and_condition = $_REQUEST['terms_and_condition'];
            }
             if(isset($_REQUEST['last_date_of_membership_enrollment'])){
                $model->last_date_of_membership_enrollment = date("Y-m-d H:i:s", strtotime($_REQUEST['last_date_of_membership_enrollment']));
            }
            if(isset($_REQUEST['payment_terms'])){
                $model->payment_terms = $_REQUEST['payment_terms'];
            }
            if(isset($_REQUEST['preferred_hybrid_payment'])){
                $model->preferred_hybrid_payment = $_REQUEST['preferred_hybrid_payment'];
            }
            if(isset($_REQUEST['hybrid_payment_must_exclude'])){
                $model->hybrid_payment_must_exclude = $_REQUEST['hybrid_payment_must_exclude'];
            }
            if(isset($_REQUEST['restrict_membership_to'])){
                $model->restrict_membership_to = $_REQUEST['restrict_membership_to'];
            }
            $model->merchant_id = $merchant_id;
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
             if($model->save()){
               header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => "This community is created successfully")
                           );
                
            }else{
                 header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => "Validation issue: This community was not created")
                           );
            }
        }
        
        /**
         * This is the function that modifies community info
         */
        public function actionmodifycommunity(){
            
             $_id = $_REQUEST['id'];
            $model=  BuyerCommunity::model()->findByPk($_id);
            
            $model->name = $_REQUEST['name'];
            if(isset($_REQUEST['description'])){
                $model->description = $_REQUEST['description'];
            }
            $model->code  = $_REQUEST['code'];
            $model->slot_id = $_REQUEST['slot_id'];
            $model->delivery_preference = $_REQUEST['delivery_preference'];
            if(isset($_REQUEST['address_of_centralized_delivery'])){
                $model->address_of_centralized_delivery = $_REQUEST['address_of_centralized_delivery'];
            }
            if(isset($_REQUEST['place_id'])){
                $model->place_id = $_REQUEST['place_id'];
            }
             if(isset($_REQUEST['city_of_delivery'])){
                $model->city_of_delivery = $_REQUEST['city_of_delivery'];
            }
             if(isset($_REQUEST['state_of_delivery'])){
                $model->state_of_delivery = $_REQUEST['state_of_delivery'];
            }
            if(isset($_REQUEST['status'])){
                $model->status = $_REQUEST['status'];
            }
            if(isset($_REQUEST['minimum_purchase_per_member'])){
                $model->minimum_purchase_per_member = $_REQUEST['minimum_purchase_per_member'];
            }
            if(isset($_REQUEST['estimated_minimum_number_of_members_required'])){
                $model->estimated_minimum_number_of_members_required = $_REQUEST['estimated_minimum_number_of_members_required'];
            }
            if(isset($_REQUEST['minimum_purchases_required_before_activation'])){
                $model->minimum_purchases_required_before_activation = $_REQUEST['minimum_purchases_required_before_activation'];
            }
             if(isset($_REQUEST['date_of_activation'])){
                $model->date_of_activation = date("Y-m-d H:i:s", strtotime($_REQUEST['date_of_activation']));
            }
             if(isset($_REQUEST['start_date_of_delivery'])){
                $model->start_date_of_delivery = date("Y-m-d H:i:s", strtotime($_REQUEST['start_date_of_delivery']));
            }
            if(isset($_REQUEST['last_date_of_delivery'])){
                $model->last_date_of_delivery = date("Y-m-d H:i:s", strtotime($_REQUEST['last_date_of_delivery']));
            }
            if(isset($_REQUEST['delivery_cost_per_slot'])){
                $model->delivery_cost_per_slot = $_REQUEST['delivery_cost_per_slot'];
            }
             if(isset($_REQUEST['cost_per_slot'])){
                $model->cost_per_slot = $_REQUEST['cost_per_slot'];
            }
            if(isset($_REQUEST['terms_and_condition'])){
                $model->terms_and_condition = $_REQUEST['terms_and_condition'];
            }
             if(isset($_REQUEST['last_date_of_membership_enrollment'])){
                $model->last_date_of_membership_enrollment = date("Y-m-d H:i:s", strtotime($_REQUEST['last_date_of_membership_enrollment']));
            }
            if(isset($_REQUEST['payment_terms'])){
                $model->payment_terms = $_REQUEST['payment_terms'];
            }
            if(isset($_REQUEST['preferred_hybrid_payment'])){
                $model->preferred_hybrid_payment = $_REQUEST['preferred_hybrid_payment'];
            }
            if(isset($_REQUEST['hybrid_payment_must_exclude'])){
                $model->hybrid_payment_must_exclude = $_REQUEST['hybrid_payment_must_exclude'];
            }
            if(isset($_REQUEST['restrict_membership_to'])){
                $model->restrict_membership_to = $_REQUEST['restrict_membership_to'];
            }
             if(isset($_REQUEST['merchant_id'])){
                $model->merchant_id = $_REQUEST['merchant_id'];
            }
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
             if($model->save()){
               header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => "This community is updated successfully")
                           );
                
            }else{
                 header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => "Validation issue: This community was not updated")
                           );
            }
        }
        
        
        /**
         * This is the function that deletes one community
         */
        public function actiondeleteonecommunity(){
            $_id = $_REQUEST['id'];
            $model=  BuyerCommunity::model()->findByPk($_id);
           
            
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' community was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
        }
        
        
        /**
         * This is the function to list all commnities that belongs to a merchant
         */
        public function actionlistAllCommunityCreatedByMerchant(){
            
            $model = new User;
            $user_id = Yii::app()->user->id;
            
            $merchant_id = $model->getTheMerchantIdOfThisUser($user_id);
            
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='merchant_id=:merid';
              $criteria->params = array(':merid'=>$merchant_id);
              $community= BuyerCommunity::model()->findAll($criteria);
              if($community===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "community" => $community,
                                   
                    
                            ));
                       
                       
                }
        }
        
        
        /**
         * This is the function that recreates a community from an existing one
         */
        public function actionrecreatefromanothercommunity(){
            
            $model = new BuyerCommunity;
            
            $model->name = $_REQUEST['name'];
            if(isset($_REQUEST['description'])){
                $model->description = $_REQUEST['description'];
            }
           $model->merchant_id = $_REQUEST['merchant_id'];
           $model->code  = $model->generateTheCodeForThisCommunity($model->merchant_id);
            
            $model->slot_id = $_REQUEST['slot_id'];
            $model->delivery_preference = $_REQUEST['delivery_preference'];
            if(isset($_REQUEST['address_of_centralized_delivery'])){
                $model->address_of_centralized_delivery = $_REQUEST['address_of_centralized_delivery'];
            }
            if(isset($_REQUEST['place_id'])){
                $model->place_id = $_REQUEST['place_id'];
            }
             if(isset($_REQUEST['city_of_delivery'])){
                $model->city_of_delivery = $_REQUEST['city_of_delivery'];
            }
             if(isset($_REQUEST['state_of_delivery'])){
                $model->state_of_delivery = $_REQUEST['state_of_delivery'];
            }
            if(isset($_REQUEST['status'])){
                $model->status = $_REQUEST['status'];
            }
            if(isset($_REQUEST['minimum_purchase_per_member'])){
                $model->minimum_purchase_per_member = $_REQUEST['minimum_purchase_per_member'];
            }
            if(isset($_REQUEST['estimated_minimum_number_of_members_required'])){
                $model->estimated_minimum_number_of_members_required = $_REQUEST['estimated_minimum_number_of_members_required'];
            }
            if(isset($_REQUEST['minimum_purchases_required_before_activation'])){
                $model->minimum_purchases_required_before_activation = $_REQUEST['minimum_purchases_required_before_activation'];
            }
             if(isset($_REQUEST['date_of_activation'])){
                $model->date_of_activation = date("Y-m-d H:i:s", strtotime($_REQUEST['date_of_activation']));
            }
             if(isset($_REQUEST['start_date_of_delivery'])){
                $model->start_date_of_delivery = date("Y-m-d H:i:s", strtotime($_REQUEST['start_date_of_delivery']));
            }
            if(isset($_REQUEST['last_date_of_delivery'])){
                $model->last_date_of_delivery = date("Y-m-d H:i:s", strtotime($_REQUEST['last_date_of_delivery']));
            }
            if(isset($_REQUEST['delivery_cost_per_slot'])){
                $model->delivery_cost_per_slot = $_REQUEST['delivery_cost_per_slot'];
            }
             if(isset($_REQUEST['cost_per_slot'])){
                $model->cost_per_slot = $_REQUEST['cost_per_slot'];
            }
            if(isset($_REQUEST['terms_and_condition'])){
                $model->terms_and_condition = $_REQUEST['terms_and_condition'];
            }
             if(isset($_REQUEST['last_date_of_membership_enrollment'])){
                $model->last_date_of_membership_enrollment = date("Y-m-d H:i:s", strtotime($_REQUEST['last_date_of_membership_enrollment']));
            }
            if(isset($_REQUEST['payment_terms'])){
                $model->payment_terms = $_REQUEST['payment_terms'];
            }
            if(isset($_REQUEST['preferred_hybrid_payment'])){
                $model->preferred_hybrid_payment = $_REQUEST['preferred_hybrid_payment'];
            }
            if(isset($_REQUEST['hybrid_payment_must_exclude'])){
                $model->hybrid_payment_must_exclude = $_REQUEST['hybrid_payment_must_exclude'];
            }
            if(isset($_REQUEST['restrict_membership_to'])){
                $model->restrict_membership_to = $_REQUEST['restrict_membership_to'];
            }
                       
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
             if($model->save()){
               header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => "This community is created successfully")
                           );
                
            }else{
                 header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => "Validation issue: This community was not created")
                           );
            }
            
            
            
        }
        
        /**
         * This is the function that retrieves a merchant id of a user
         */
        public function getTheMerchantIdOfThisUser($user_id){
            $model = new User;
            return $model->getTheMerchantIdOfThisUser($user_id);
        }
}
