<?php

class InterClusterRateController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listallinterclusterrates','setthisinterclusterdeliveryrate','modifythisinterclusterdeliveryrate',
                                    'removethisinterclusterdeliveryrate'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all inter-cluster rates
         */
        public function actionlistallinterclusterrates(){
            $model = new InterClusterRate;
             $rates = InterClusterRate::model()->findAll();
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "rate" => $rates,
                                   
                    
                            ));
        }
        
        
        /**
         * This is the function that sets an inter cluster delivery rate
         */
        public function actionsetthisinterclusterdeliveryrate(){
            $model = new InterClusterRate;
            
            $model->first_cluster_id = $_POST['id'];
             $model->second_cluster_id = $_POST['second_cluster_id'];
             $model->inter_cluster_base_rate = $_POST['inter_cluster_base_rate'];
             $model->inter_cluster_maximum_base_weight = $_POST['inter_cluster_maximum_base_weight'];
             $model->inter_cluster_per_additional_kg = $_POST['inter_cluster_per_additional_kg'];
             $model->preference = $_POST['preference'];
             
             $model->create_time = new CDbExpression('NOW()');
             $model->create_user_id = Yii::app()->user->id;
             
             if($model->first_cluster_id != $model->second_cluster_id){
                 if($model->isThisInterClusterRateAlreadySet($model->first_cluster_id,$model->second_cluster_id,$model->preference) == false){
                 if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'This inter cluster rate is set successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'Attempt to set this inter cluster rate failed';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                 
             }else{
                 //$result['success'] = 'false';
                         $msg = 'This inter cluster rate is already set before, therefore the request is ignored';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
             }
                 
                 
             }else{
                  $msg = 'Ilegal operation. You cannot set an inter cluster rate of the same cluster, therefore the request is ignored';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                 
             }
             
             
             
             
        }
        
        
        
         /**
         * This is the function that modifies an inter cluster delivery rate
         */
        public function actionmodifythisinterclusterdeliveryrate(){
           
            $first_cluster_id = $_POST['id'];
             $second_cluster_id = $_POST['second_cluster_id'];
             $preference = $_POST['preference'];
           if($this->isThisInterClusterRateAlreadySet($first_cluster_id,$second_cluster_id,$preference)){
               $intercluster_id = $this->getThisInterClusterId($first_cluster_id,$second_cluster_id);
             $model= InterClusterRate::model()->findByPk($intercluster_id);
             $model->first_cluster_id =$first_cluster_id;
             $model->second_cluster_id = $second_cluster_id;
             $model->inter_cluster_base_rate = $_POST['inter_cluster_base_rate'];
             $model->inter_cluster_maximum_base_weight = $_POST['inter_cluster_maximum_base_weight'];
             $model->inter_cluster_per_additional_kg = $_POST['inter_cluster_per_additional_kg'];
             $model->preference = $_POST['preference'];
             $model->update_time = new CDbExpression('NOW()');
             $model->update_user_id = Yii::app()->user->id;
             
             
                 if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'This inter cluster rate is updated successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'Attempt to update this inter cluster rate failed';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                 
             }else{
                 //$result['success'] = 'false';
                         $msg = 'This inter cluster rate is not current set, therefore the request is ignored';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
             }
             
             
        }
        
        
        
        /**
         * This is the function that modifies an inter cluster delivery rate
         */
        public function actionremovethisinterclusterdeliveryrate(){
           
            $first_cluster_id = $_POST['id'];
             $second_cluster_id = $_POST['second_cluster_id'];
              $preference = $_POST['preference'];
             
           if($this->isThisInterClusterRateAlreadySet($first_cluster_id,$second_cluster_id,$preference)){
               $intercluster_id = $this->getThisInterClusterId($first_cluster_id,$second_cluster_id);
               $model= InterClusterRate::model()->findByPk($intercluster_id);
             
                 if($model->delete()){
                         // $result['success'] = 'true';
                          $msg = 'This inter cluster rate is successfully deleted';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'Attempt to delete this inter cluster rate failed';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
                 
             }else{
                 //$result['success'] = 'false';
                         $msg = 'This inter cluster rate is not current set, therefore the request is ignored';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
             }
             
             
        }
        
        
        /**
         * This is the function that confirms if an intercluster rate is already set
         */
        public function isThisInterClusterRateAlreadySet($first_cluster_id,$second_cluster_id,$preference){
            $model = new InterClusterRate;
            return $model->isThisInterClusterRateAlreadySet($first_cluster_id,$second_cluster_id,$preference);
        }
        
        
        /**
         * This is the function that retrieves a cluster id
         */
        public function getThisInterClusterId($first_cluster_id,$second_cluster_id){
            $model = new InterClusterRate;
            return $model->getThisInterClusterId($first_cluster_id,$second_cluster_id);
        }
}
