<?php

class CommunityTransactionController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','submittingcommunitymembertransaction'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listThisCommunityTransactions'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all transactions from members of a community
         */
        public function actionlistThisCommunityTransactions(){
            $model = new CommunityTransaction;
            $community_id = $_REQUEST['community_id'];
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='community_id=:commid';
              $criteria->params = array(':commid'=>$community_id);
              $community= CommunityTransaction::model()->findAll($criteria);
              if($community===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "transaction" => $community,
                                   
                    
                            ));
                       
                       
                }
            
        }
        
        /**
         * This is the function that submits a community member transaction
         */
        public function actionsubmittingcommunitymembertransaction(){
            $model = new CommunityTransaction;
            
            $model->community_id = $_REQUEST['community_id'];
            $model->user_id = $_REQUEST['user_id'];
            $model->payment_term_requested = $_REQUEST['payment_terms'];
            $model->payment_status ="pending";
            $model->slot_quantity_purchased = $_REQUEST['quantity_purchased'];
            $model->address_of_delivery = $_REQUEST['place_of_delivery'];
            $model->city_of_delivery = $_REQUEST['city_id'];
            $model->date_enrolled = new CDbExpression('NOW()');
            $model->sequence_number = $model->getTheSequenceNumberOfThisTransaction($model->community_id,$model->slot_quantity_purchased);
            $model->remaining_number_of_slot_before_activation = $model->getTheNumberOfRemainingSlotsBeforeActivation($model->community_id,$model->sequence_number);
            $model->estimated_number_of_members_required_before_activation = $model->getTheRemainingNumberOfMembersBeforeActivation($model->community_id,$model->sequence_number);
            $model->delivery_status = "undelivered";
            $model->buyer_name = $_REQUEST['buyer_name'];
            $model->buyer_mobile_number = $_REQUEST['buyer_mobile_number'];
            $model->buyer_email_address = $_REQUEST['email_address'];
            $model->delivery_preference = $_REQUEST['delivery_preference'];
            $model->total_cost_of_delivery = $_REQUEST['total_cost_of_delivery'];
            $model->recipient_name = $_REQUEST['recipient_name'];
            $model->recipient_mobile_number = $_REQUEST['mobile_number'];
            $model->total_slot_cost = $_REQUEST['total_cost'];
            $model->grand_cost = $_REQUEST['grand_cost'];
            $model->subscription_type = $_REQUEST['subscription_type'];
            $model->subscription_end_date = $_REQUEST['subscription_end_date'];
            
            if($model->save()){
               header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "data" => $model)
                           );
                
            }else{
                 header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => "Validation issue: This transaction was not executed. Please try again or contact customer service unit for assistance",
                                        "sequence"=>$model->sequence_number,
                                        "num_of_slots_remaining"=>$model->remaining_number_of_slot_before_activation,
                                        "remainig_member_number"=>$model->estimated_number_of_members_required_before_activation,
                                        "community"=>$model->community_id,
                                        "payment_term_requested" => $model->payment_term_requested,
                                        "payment_status"=>$model->payment_status,
                                        "slot_quantity_purchased"=>$model->slot_quantity_purchased,
                                        
                                
                           ));
            }
            
            
            
                    
            
            
        }
}
