<?php

class ProductTypeController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','listAllProductTypesOfThisCategory','getThisProductTypeDetails'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','addingnewproducttype','deleteoneproducttype','modifyproducttype','listAllProductTypesInThisSubcategory'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}
        
        
        /**
         * This is the function that list all product type in a subcategory
         */
        public function actionlistAllProductTypesInThisSubcategory(){
            
             $model = new ProductType;
            
            $subcategory_id = $_REQUEST['subcategory_id'];
            
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='subcategory_id=:id';
              $criteria->params = array(':id'=>$subcategory_id);
              $producttype= ProductType::model()->findAll($criteria);
              if($producttype===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "type" => $producttype,
                                   
                    
                            ));
                       
                       
                }
        }
        
        
        
        

	/**
         * This is the function that adds new product type
         */
        public function actionaddingnewproducttype(){
            
            $model=new ProductType;

		
                $model->name = $_POST['name'];
                $model->subcategory_id = $_POST['subcategory_id'];
                if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                if(isset($_POST['is_with_measurement'])){
                   $model->is_with_measurement = $_POST['is_with_measurement']; 
                }else{
                    $model->is_with_measurement=0;
                }
                if(isset($_POST['is_available'])){
                   $model->is_available = $_POST['is_available']; 
                }else{
                    $model->is_available=0;
                }
                                 
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                
                $icon_error_counter = 0;
                
                 if($_FILES['icon']['name'] != ""){
                    if($model->isIconTypeAndSizeLegal()){
                        
                       $icon_filename = $_FILES['icon']['name'];
                     
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                         
                           
                       if($model->save()) {
                        
                                $msg = "'$model->name' product type was added successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$model->name'  product type was not added";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                   }elseif($icon_error_counter > 0){
                        $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        } 
            
            
        }
        
        
        
        /**
         * This is the function that updates the product type information
         */
        public function actionmodifyproducttype(){
            
             $_id = $_POST['id'];
             $model= ProductType::model()->findByPk($_id);
             
             $model->name = $_POST['name'];
             $model->subcategory_id = $_POST['subcategory_id'];
                if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
               if(isset($_POST['is_with_measurement'])){
                   $model->is_with_measurement = $_POST['is_with_measurement']; 
                }else{
                   $model->is_with_measurement=0; 
                }  
                if(isset($_POST['is_available'])){
                   $model->is_available = $_POST['is_available']; 
                }else{
                    $model->is_available=0;
                }
                                 
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                
                $icon_error_counter = 0;
                
                 if($_FILES['icon']['name'] != ""){
                    if($model->isIconTypeAndSizeLegal()){
                        
                       $icon_filename = $_FILES['icon']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = $model->retrieveThePreviousIconName($_id);
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                           
                           
                       if($model->save()) {
                        
                                $msg = "'$model->name' product type was updated successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$model->name' product type  was not updated";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                   }elseif($icon_error_counter > 0){
                        $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        } 
         
        }
        
        
        
         /**
         * This is the function that deletes a product type from the database
         */
        public function actiondeleteoneproducttype(){
            
            $_id = $_POST['id'];
            $model= ProductType::model()->findByPk($_id);
            
            
            if($model->isTheRemovalOfProductTypeImageASuccess($_id)){
                //get the category name
            $producttype = $model->getThisProductTypeName($_id);
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$producttype' product type was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion was unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
                
            }else{
                $data['success'] = 'false';
                    $data['msg'] = 'deletion was unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            }
            
            
            
        }
        
        
        /**
         * This is the function that list the product types of a category
         */
        public function actionlistAllProductTypesOfThisCategory(){
            $model = new SubCategory;
            $category_id = $_REQUEST['category_id'];
            $target = [];
            
            //retrieve all subcategories of this category
            $subcategories = $model->getAllSubcategoriesOfThisCategoryForNgadi($category_id);
            
            if($subcategories != null){
                foreach($subcategories as $subcat){
                
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='subcategory_id=:subcat_id and is_available=1';
                    $criteria->params = array(':subcat_id'=>$subcat);
                    $types = ProductType::model()->findAll($criteria); 
                    
                    foreach($types as $type){
                        $target[] = $type;
                        
                    }
                
            }
            
           header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "type" => $target)
                            );
                
            }else{
                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "type" => $target)
                            );
                
            }
             
            
            
            
        }
        
        
        /**
         * This is the function that gets this product type details
         */
        public function actiongetThisProductTypeDetails(){
            
            $type_id = $_REQUEST['type_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:typeid';
            $criteria->params = array(':typeid'=>$type_id);
            $type = ProductType::model()->find($criteria); 
            
             header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "type" => $type)
                            );
            
            
            
        }
}
