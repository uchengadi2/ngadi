<?php

class UserController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','Login','newuserregisteration'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','Logout','listAllUsers','deleteoneuser','addnewuser','modifyuser','AllUserDomainType',
                                    'retrievethisuserinformation','ChangePasswordByOwner','ChangeParameterByOwner','listMerchantAllUsers','addnewmerchantdomainuser',
                                    'modifymerchantdomainuser','changeauserpassword','getTheLoggedInUser'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	public function actionLogin()
	{
		
             $model = new User('login');
            
                                             
               
                              
                $model->username = $_POST['username'];
                $model->password = $_POST['password'];
                
                //determine the users id
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='username=:name';
                $criteria->params = array(':name'=>$_POST['username']);
                $id = User::model()->find($criteria);   
                
               $name = $id['name'];
              //validate the users logon credentials
              
         if($this->validatePassword($model, $id->id,$model->password) && $model->login()) {
           // if($model->login()) {
                      header('Content-Type: application/json');
                      $msg = "$name";
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "msg" => $msg,
                           "firstname"=>$id['name'],
                           "userid"=>$id['id']
                            )
                           
                       );
          // }  

        }else {
                     header('Content-Type: application/json');
                      $msg= 'Incorrect username or password.';
                     echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => $msg,
                         "firstname"=>$id['name']
                             )
                       );
                       
                }
                
            
                
		
		
	}
        
        
         /**
	 * Logs out the current user and redirect to homepage.
	 */
	public function actionLogout()
	{
		Yii::app()->user->logout();
		//$this->redirect(Yii::app()->homeUrl);
                header('Content-Type: application/json');
                      $msg= "You just logged out. Please come again";
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "msg" => $msg
                            )
                           
                       );
	}
        
        
                /*
         * validate the password during authorisation
         */
        public function validatePassword($model, $id, $password){
         
            //determine the existing password
            
           $criteria = new CDbCriteria();
           $criteria->select = 'id, password';
           $criteria->condition='id=:id';
           $criteria->params = array(':id'=>$id);
           $existing_password = User::model()->find($criteria);   
        
           return $model->hashPassword($password)=== $existing_password->password;
           
            
        }
        
        
        /**
         * This is the function that list all users in the marketplace
         */
        public function actionlistAllUsers(){
           
             $user = User::model()->findAll();
                if($user===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "user" => $user)
                           );
                       
                }
        }
        
        
        /**
         * This is the function that adds new user to the marketplace
         */
        public function actionaddnewuser(){
            $model=new User;
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
            if(isset($_POST['type'])){
                   $model->type = $_POST['type'];
            }
            $model->name = $_POST['name'];
            $model->role = $_POST['role'];
            if($model->type =="platform"){
                $model->type_id = $_POST['platform_type_id'];
            }else{
                $model->type_id = $_POST['type_id'];
            }
            //$model->type_id = $_POST['type_id'];
            $model->status = strtolower($_POST['status']);
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            $password = $_POST['password'];
            $password_repeat = $_POST['confirm_password'];
            
            if($model->isThisUserAlreadyExistingOnThePlatform($model) == false){
                if($password === $password_repeat){
                     $model->password = $password;
                     $model->password_repeat = $password_repeat;
                     
                     if($model->getPasswordMinLengthRule($password)){
                         if($model->getPasswordMaxLengthRule($password )){
                             if($model->getPasswordCharacterPatternRule($password)){
                                 $icon_error_counter = 0;
                                     if($_FILES['picture']['name'] != ""){
                                            if($model->isIconTypeAndSizeLegal()){
                       
                                                $icon_filename = $_FILES['picture']['name'];
                                                                       
                                            }else{
                       
                                                $icon_error_counter = $icon_error_counter + 1;
                                                
                                            }//end of the determine size and type statement
                                        }else{
                                            $icon_filename = NULL;
                                            
                                         }//end of the if icon is empty statement
                  
                             if($icon_error_counter ==0){
                                    if($model->validate()){
                                        $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                    if($model->save()) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                                // $result['success'] = 'true';
                                                $msg = 'User Creation was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                              
                              
                                            }else {
                                                $msg = 'User creation was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this User";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                     }
                        
                                                                
                                }else{
                                    $msg = 'User creation was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
                                 
                     
                             }else{
                                 $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                                    header('Content-Type: application/json');
                                        echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                    )); 
                                 
                             }
                         }else{
                             $msg = 'The maximum Password length allowed is sixty(60)';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                             
                         }
                         
                         
                     }else{
                         $msg = 'The minimum Password length allowed is eight(8)';
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                       )); 
                         
                     }
           
                    
                }else{
                    $msg = 'Repeat Password do not match the new password';
                        header('Content-Type: application/json');
                             echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                            )); 
                }
                
                
            }else{
                $msg = "This user already exist on the marketplace so the request will be discarded";
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg
                       )); 
            }
            
        }
        
        
        
        
        /**
         * This is the function that modifies a  user information to the marketplace
         */
        public function actionmodifyuser(){
           
            $_id = $_POST['id'];
           $model=User::model()->findByPk($_id);
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
            if(isset($_POST['type'])){
                   $model->type = $_POST['type'];
            }
            $model->name = $_POST['name'];
            $model->role = $_POST['role'];
            if($model->type =="platform"){
                $model->type_id = $_POST['platform_type_id'];
            }else{
                $model->type_id = $_POST['type_id'];
            }
            $model->status = strtolower($_POST['status']);
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            $password = "";
            $password_repeat = "";
            
             $icon_error_counter = 0;
                      if($_FILES['picture']['name'] != ""){
                             if($model->isIconTypeAndSizeLegal()){
                       
                                 $icon_filename = $_FILES['picture']['name'];
                                                                       
                             }else{
                       
                                 $icon_error_counter = $icon_error_counter + 1;
                                                
                             }//end of the determine size and type statement
                      }else{
                             $icon_filename = $model->retrieveThePreviousIconName($_id);
                                            
                      }//end of the if icon is empty statement
                  
                      if($icon_error_counter ==0){
                           if($model->validate()){
                              $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                  if($model->isTheUserModificationASuccess($_id,$model->type,$model->type_id,$model->status,$model->name,$model->picture)) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                                // $result['success'] = 'true';
                                                $msg = 'User update was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                              
                              
                                            }else {
                                                $msg = 'Userrr update was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this User";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                        }
                        
                                       
                         
                                }else{
                                    $msg = 'User update was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
            
        }
        
        
        
        /**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actiondeleteoneuser()
	{
            //delete one user
            $_id = $_REQUEST['id'];
            $name = $_REQUEST['name'];
            $model=User::model()->findByPk($_id);
            if($model === null){
                $msg = "This model is null and there are no data to delete";
                        header('Content-Type: application/json');
                        echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            
                            "msg" => $msg)
                       );
            }else if($model->isTheRemovalOfUserImageASuccess($_id)){
                if($model->delete()){
                    if($model->deleteRoleAssignedToAUser($model->role, $_id)){
                         $msg = "'$name' was successfully deleted";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => $msg)
                                );
                        
                    }else{
                        $msg = "The '$name' was deleted but his/her record(s) still exist in the role assignment table";
                        header('Content-Type: application/json');
                        echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            
                            "msg" => $msg)
                       );
                        
                        
                    }
                    
                    
                }else{
                     $msg = "User record deletion was not successful.Please contact customer service for assistance";
                        header('Content-Type: application/json');
                        echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            
                            "msg" => $msg)
                       );
                            
                    
                }
                
                  
          }else{
               $msg = "This user could not be deleted as there was issue in removing his/her picture. Please contact customer service for assistance";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
              
              
              
          }              
                                      
           
                    
          
	}
        
        
        /**
         * This is the function that list all user domain types
         */
        public function actionAllUserDomainType(){
            
            $type = $_REQUEST['type'];
            
            if($type == 'merchant'){
                $target = $this->listAllMerchantsInTheMarketplace();
            }else if($type == 'contractor'){
                $target = $this->listAllContractorsInTheMarketplace();
            }
            
            if($target===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "usertype" => $target,
                                   
                    
                            ));
                       
                }
        }
        
        
        
        /**
         * This is the function that list all merchants in the marketplace
         */
        public function listAllMerchantsInTheMarketplace(){
            $model = new Merchant;
            return $model->listAllMerchantsInTheMarketplace();
        }
        
        
        /**
         * This is the function that list all contractors in the marketplace
         */
        public function listAllContractorsInTheMarketplace(){
            $model = new Contractor;
            return $model->listAllContractorsInTheMarketplace();
        }
        
        
        /**
         * This is the function that adds new customer user to the marketplace
         */
        public function actionnewuserregisteration(){
            $model=new User;
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
            $model->type = "customer";
            $model->name = $_POST['name'];
            $model->role = "user";
            $model->type_id = null;
            $model->status = "active";
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            $password = $_POST['password'];
            $password_repeat = $_POST['confirm_password'];
            
            if($model->isThisUserAlreadyExistingOnThePlatform($model) == false){
                if($password === $password_repeat){
                     $model->password = $password;
                     $model->password_repeat = $password_repeat;
                     
                     if($model->getPasswordMinLengthRule($password)){
                         if($model->getPasswordMaxLengthRule($password )){
                             if($model->getPasswordCharacterPatternRule($password)){
                                 $icon_error_counter = 0;
                                     if($_FILES['picture']['name'] != ""){
                                            if($model->isIconTypeAndSizeLegal()){
                       
                                                $icon_filename = $_FILES['picture']['name'];
                                                                       
                                            }else{
                       
                                                $icon_error_counter = $icon_error_counter + 1;
                                                
                                            }//end of the determine size and type statement
                                        }else{
                                            $icon_filename = NULL;
                                            
                                         }//end of the if icon is empty statement
                  
                             if($icon_error_counter ==0){
                                    if($model->validate()){
                                        $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                    if($model->save()) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                                // $result['success'] = 'true';
                                                $msg = 'You have sucessfully been registered';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg,
                                                    "firstname"=>$model->name,
                                                    "userid"=>$model->id)
                                                );
                              
                              
                                            }else {
                                                $msg = 'User registeration was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this User";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                     }
                        
                                                                
                                }else{
                                    $msg = 'User creation was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
                                 
                     
                             }else{
                                 $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                                    header('Content-Type: application/json');
                                        echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                    )); 
                                 
                             }
                         }else{
                             $msg = 'The maximum Password length allowed is sixty(60)';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                             
                         }
                         
                         
                     }else{
                         $msg = 'The minimum Password length allowed is eight(8)';
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                       )); 
                         
                     }
           
                    
                }else{
                    $msg = 'Repeat Password do not match the new password';
                        header('Content-Type: application/json');
                             echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                            )); 
                }
                
                
            }else{
                $msg = "This user already exist on the marketplace so the request will be discarded";
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg
                       )); 
            }
            
        }
        
        
         /**
         * This is the function that retrieves a user's information
         */
        public function actionretrievethisuserinformation(){
            $user_id = $_REQUEST['user_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$user_id);
            $user= User::model()->find($criteria);
            
            //retrieve the membership details of this user
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='member_id=:userid';
            $criteria->params = array(':userid'=>$user_id);
            $membership= Membership::model()->find($criteria);
            
             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() == 0,
                                "user" => $user,
                                "membership"=>$membership
                       )); 
            
            
        }
        
        
        /**
	 * perform own password change
	 */
	public function actionChangePasswordByOwner()
	{
		
            //obtain the current password from the database
            $userid = Yii::app()->user->id;
            
            $model = User::model()->findByPk($userid); 
                        
            $current_password = $_POST['password'];
            $password = $_POST['new_password'];
            $password_repeat = $_POST['password_repeat'];
                 
            //determine the value of the stored passwoord
            
            $criteria2 = new CDbCriteria();
            $criteria2->select = 'id, password';
            $criteria2->condition='id=:id';
            $criteria2->params = array(':id'=>$userid);
            $user = User::model()->find($criteria2);
            
            //ascertain that the new password is the same with the stored password
            if($model->hashPassword($current_password) === $user->password){
                               
                if($password === $password_repeat){
                    
                    $model->password = $password;
                    $model->password_repeat = $password_repeat;
                    
                    if($model->getPasswordMinLengthRule($password)){
                        
                        if($model->getPasswordMaxLengthRule($password )){
                            
                            if($model->getPasswordCharacterPatternRule($password)){
                                
                                    //$model->password = $model->hashPassword($newpassword);
                            if($model->save()){
                                $msg = 'Password was successfully changed';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                         "msg" => $msg,
                                ));
                 
                            }else{
                            $msg = 'Password change was not successful';
                             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                     "msg" => $msg,
                             ));  
                 
                         }
                                
                                
                                
                                
                            }else{
                                
                                $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() != 0,
                                 "msg" => $msg,
                                )); 
                            }
                            
                        }else{
                                $msg = 'The maximum Password length allowed is sixty(60)';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                            )); 
                            
                        }
                        
                        
                    }else{
                        $msg = 'The minimum Password length allowed is eight(8)';
                             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => $msg,
                       )); 
                        
                        
                    }
                
                //effect the change 
              /**
              $cmd =Yii::app()->db->createCommand();  
              $cmd->update('user',
                	array('password'=>$password,
	         	),
			"id = $userid"
		);
               * 
               */
             
              
                
                
            }else{
               $msg = 'Repeat Password do not match the new password';
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" => $msg,
                       )); 
                
                
            }
                
                
            }else{
                 $msg = 'Invalid current password. Try again';
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" => $msg,
                       )); 
                
                
            }
            
    
               
	}
        
        
        /**
         * This is the function that effects an update on user details
         */
        public function actionChangeParameterByOwner(){
            $user_id = $_REQUEST['user_id'];
            
            $model = User::model()->findByPk($user_id);
            
            $model->name = $_REQUEST['name'];
            
            if($model->save()){
                 $msg = 'User parameter(s) updated successfully';
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg" => $msg,
                           "name"=>$model->name
                       )); 
                
            }else{
                 $msg = 'User parameter could not be updated successfully. Check your data and try again';
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" => $msg,
                          
                       )); 
            }
        }
        
        
         /**
         * This is the function that retrieves the logged in user
         */
        public function actiongetTheLoggedInUser(){
            $user_id = Yii::app()->user->id;
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "user_id" => $user_id,
                          
                       ));
            
            
        }
        
        
        /**
         * This is the function that list all users of a merchant
         */
        public function actionlistMerchantAllUsers(){
            $merchant_id = $_REQUEST['merchant_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='type_id=:typeid';
            $criteria->params = array(':typeid'=>$merchant_id);
            $users = User::model()->findAll($criteria);
            
            header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "user" => $users,
                          
                       ));
            
            
            
            
        }
        
        
        
         /**
         * This is the function that adds new user to the marketplace
         */
        public function actionaddnewmerchantdomainuser(){
            $model=new User;
            $model->email = $_POST['email'];
            $model->username = $_POST['email'];
            if(isset($_POST['type'])){
                   $model->type = $_POST['type'];
            }
            $model->name = $_POST['name'];
            $model->role = $_POST['role'];
            $model->type_id = $_POST['type_id'];
            $model->status = strtolower($_POST['status']);
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            $password = $_POST['password'];
            $password_repeat = $_POST['confirm_password'];
            
            if($model->isThisUserAlreadyExistingOnThePlatform($model) == false){
                if($password === $password_repeat){
                     $model->password = $password;
                     $model->password_repeat = $password_repeat;
                     
                     if($model->getPasswordMinLengthRule($password)){
                         if($model->getPasswordMaxLengthRule($password )){
                             if($model->getPasswordCharacterPatternRule($password)){
                                 $icon_error_counter = 0;
                                     if($_FILES['picture']['name'] != ""){
                                            if($model->isIconTypeAndSizeLegal()){
                       
                                                $icon_filename = $_FILES['picture']['name'];
                                                                       
                                            }else{
                       
                                                $icon_error_counter = $icon_error_counter + 1;
                                                
                                            }//end of the determine size and type statement
                                        }else{
                                            $icon_filename = NULL;
                                            
                                         }//end of the if icon is empty statement
                  
                             if($icon_error_counter ==0){
                                    if($model->validate()){
                                        $model->picture = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                                        
                           
                                    if($model->save()) {
                                        if(isset($model->role)){
                                           if($model->assignRoleToAUser($model->role, $model->id)) {
                                                // $result['success'] = 'true';
                                                $msg = 'User Creation was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() == 0,
                                                     "msg" => $msg)
                                                );
                              
                              
                                            }else {
                                                $msg = 'User creation was not successful';
                                                header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                    "success" => mysqli_connect_errno() != 0,
                                                    "msg" => $msg)
                                                 );
                                                              
                                         }
                                  
                                      }else{
                                            $msg = "Role is not assigned to this User";
                                            header('Content-Type: application/json');
                                            echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                            
                                            
                                     }
                        
                                                                
                                }else{
                                    $msg = 'User creation was not successful';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysqli_connect_errno() != 0,
                                            "msg" => $msg)
                                        );
                                }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                                $msg = "Validation Error: '$model->name'  was not created successful";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                                );
                          }
                         }elseif($icon_error_counter > 0){
                                $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                                );
                         
                            }
                                 
                     
                             }else{
                                 $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                                    header('Content-Type: application/json');
                                        echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg,
                                    )); 
                                 
                             }
                         }else{
                             $msg = 'The maximum Password length allowed is sixty(60)';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                             
                         }
                         
                         
                     }else{
                         $msg = 'The minimum Password length allowed is eight(8)';
                                header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                       )); 
                         
                     }
           
                    
                }else{
                    $msg = 'Repeat Password do not match the new password';
                        header('Content-Type: application/json');
                             echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                            )); 
                }
                
                
            }else{
                $msg = "This user already exist on the marketplace so the request will be discarded";
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg
                       )); 
            }
            
        }
        
        
        
        /**
	 * perform a user password change
	 */
	public function actionchangeauserpassword()
	{
		
            //obtain the current password from the database
            $userid = $_REQUEST['id'];
            
            $model = User::model()->findByPk($userid); 
                        
            $password = $_POST['new_password'];
            $password_repeat = $_POST['password_repeat'];
                 
            //determine the value of the stored passwoord
            
                                      
              if($password === $password_repeat){
                    
                    $model->password = $password;
                    $model->password_repeat = $password_repeat;
                    
                    if($model->getPasswordMinLengthRule($password)){
                        
                        if($model->getPasswordMaxLengthRule($password )){
                            
                            if($model->getPasswordCharacterPatternRule($password)){
                                
                                    //$model->password = $model->hashPassword($newpassword);
                            if($model->save()){
                                $msg = 'Password was successfully changed';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                        "success" => mysqli_connect_errno() == 0,
                                         "msg" => $msg,
                                ));
                 
                            }else{
                            $msg = 'Password change was not successful';
                             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                     "msg" => $msg,
                             ));  
                 
                         }
                                
                                
                                
                                
                            }else{
                                
                                $msg = 'Password must contain at least one number(0-9), at least one lower case letter(a-z), at least one upper case letter(A-Z), and at least one special character(@,&,$ etc)';
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() != 0,
                                 "msg" => $msg,
                                )); 
                            }
                            
                        }else{
                                $msg = 'The maximum Password length allowed is sixty(60)';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg,
                            )); 
                            
                        }
                        
                        
                    }else{
                        $msg = 'The minimum Password length allowed is eight(8)';
                             header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => $msg,
                       )); 
                        
                        
                    }
                
                //effect the change 
              /**
              $cmd =Yii::app()->db->createCommand();  
              $cmd->update('user',
                	array('password'=>$password,
	         	),
			"id = $userid"
		);
               * 
               */
             
              
                
                
            }else{
               $msg = 'Repeat Password do not match the new password';
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" => $msg,
                       )); 
                
                
            }
                
                
           
               
	}
        
}
