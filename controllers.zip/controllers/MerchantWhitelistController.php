<?php

class MerchantWhitelistController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','removemerchantfromwhitelist','addmerchanttowhitelist'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that add new merchant to a whitelist
         */
        public function actionaddmerchanttowhitelist(){
             $model = new MerchantWhitelist;
            
            $model->merchant_id = $_REQUEST['merchant_id'];
            $merchant_name = $_REQUEST['merchant_name'];
            
            if($model->isThisMerchantInTheWhitelist($model->merchant_id)==false){
                if($model->save()){
                $msg = "'$merchant_name' merchant is successfully added to the whitelist";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = 'Attempt to add this merchant to the whitelist was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }
                
                
            }else{
                $msg = 'This merchant is already in the whitelist and cannot be added again';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                
            }
            
        }
        
        
        /**
         * This is the function that removes a merchant from a whitelist
         */
        public function actionremovemerchantfromwhitelist(){
            
            $model = new MerchantWhitelist;
            $merchant_id = $_REQUEST['merchant_id'];
            $merchant_name = $_REQUEST['merchant_name'];
            
           if($model->isThisMerchantInTheWhitelist($merchant_id)){
                if($model->isTheRemovalOfThisMerchantFromTheWhitelistASuccess($merchant_id)){
                    $msg = "'$merchant_name' merchant is successfully removed from the whitelist";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                }else{
                    $msg = 'Attempt to remove this merchant from the whitelist was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                }
           }else{
                $msg = 'This merchant is not found in the whitelist and therefore the request is ignored';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
           }
            
        }
}
