<?php

class SlotController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','addnewproducttoslot'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','createslot','listAllSlotsCreatedByMerchant','updateslot','deleteoneslot','listAllProductsInASlot',
                                    'getSlotDetails','getTheDetailsOfAProductInASlot','modifyproductinaslot','removethisproductfromthisslot','duplicateslot',
                                    'listAllSlots'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the funcyion that creates a new slot
         */
        public function actioncreateslot(){
            
            $model = new Slot;
            
            $model->name = $_REQUEST['name'];
            $model->description = $_REQUEST['description'];
            $model->merchant_id = $_REQUEST['merchant_id'];
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            if($model->save()){
                //add the first product to the slot
                $this->addThisProductToThisSlot($model->id,$_REQUEST['pricing_id'],$_REQUEST['required_quantity']);
                 header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => "This slot is created successfully")
                           );
                
            }else{
                 header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => "Validation issue: This slot was not created")
                           );
            }
            
            
        }
        
        
        /**
         * This is the function that updates slots details
         */
        public function actionupdateslot(){
             $_id = $_POST['id'];
            $model=Slot::model()->findByPk($_id);
            $model->name = $_REQUEST['name'];
            $model->description = $_REQUEST['description'];
            $model->merchant_id = $_REQUEST['merchant_id'];
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            
            if($model->save()){
                
                 header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => "This slot is updated successfully")
                           );
                
            }else{
                 header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => "Validation issue: This slot was not updated")
                           );
            }
            
            
            
            
        }
        
        
        /**
         * This is the function that deletes one slot
         */
        public function actiondeleteoneslot(){
             $_id = $_POST['id'];
            $model=Slot::model()->findByPk($_id);
           
            
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->name' slot was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
        }
        
        
        /**
         * This is the function that adds a product to a slot
         */
        public function addThisProductToThisSlot($id,$pricing_id,$required_quantity){
            $model = new SlotHasProduct;
            return $model->addThisProductToThisSlot($id,$pricing_id,$required_quantity);
        }
        
        
        /**
         * This is the function that list all slots velongin  to a merchant
         */
        public function actionlistAllSlotsCreatedByMerchant(){
            $model = new User;
            $user_id = Yii::app()->user->id;
            
            $merchant_id = $model->getTheMerchantIdOfThisUser($user_id);
            
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='merchant_id=:merid';
              $criteria->params = array(':merid'=>$merchant_id);
              $slot= Slot::model()->findAll($criteria);
              if($slot===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "slot" => $slot,
                                   
                    
                            ));
                       
                       
                }
            
        }
        
        
        /**
         * This is the function that retrieves all products in a slot
         */
        public function actionlistAllProductsInASlot(){
               
           $slot_id = $_REQUEST['slot_id'];
          $data = [];
            
            $q = "select a.*,c.price_per_unit as price,d.required_quantity,d.slot_id,c.id as pricing_id,
                    (select name from slot where id=$slot_id) as slot,
                    (select description from slot where id=$slot_id) as description    
                    from product a
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                    JOIN slot_has_product d ON c.id=d.pricing_id
                    where d.slot_id = $slot_id
                    group by a.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
                                           
           if($data===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "product" => $data,
                                   
                    
                            ));
                       
                       
                }                     
                
            
            
        }
        
        
        /**
         * This is the function that gets the details of a slot
         */
        public function actiongetSlotDetails(){
            $slot_id = $_REQUEST['slot_id'];
            
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:slotid';
              $criteria->params = array(':slotid'=>$slot_id);
              $slot= Slot::model()->find($criteria);
              
               if($slot===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "slot" => $slot,
                                   
                    
                            ));
                       
                       
                }
              
            
            
        }
        
        /**
         * This is the function that adds new product to slot
         */
        public function actionaddnewproducttoslot(){
            $model = new SlotHasProduct;
            $slot_id = $_REQUEST['slot_id'];
            $pricing_id = $_REQUEST['pricing_id'];
            $required_quantity = $_REQUEST['required_quantity'];
            
            if($model->isProductPricingAlreadyInThisSlot($slot_id,$pricing_id) == false){
                
                if($model->addThisProductToThisSlot($slot_id,$pricing_id,$required_quantity)){
                     header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => "This product is added to this slot successfully",
                                   
                    
                            ));
                    
                }else{
                    header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => "Attempt to add this product to the slot failed. Please try again",
                                   
                    
                            ));
                }
                
            }else{
                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => "This product is already in this slot.Please choose another product to add",
                                   
                    
                            ));
            }
            
        }
        
        
        /**
         * This is the function that retrieves the details of a product in a slot
         */
        public function actiongetTheDetailsOfAProductInASlot(){
            
            $slot_id = $_REQUEST['slot_id'];
            $pricing_id = $_REQUEST['pricing_id'];
          
            
            $q = "select a.*,c.price_per_unit as price,d.required_quantity,d.slot_id, a.id as product_id,c.id as pricing_id,c.measurement_type_id as unit,
                    (select warehouse_id from inventory where id=(select inventory_id from pricing where id=$pricing_id)) as warehouse_id,
                    (select name from slot where id=$slot_id) as slot,
                    (select description from slot where id=$slot_id) as description    
                    from product a
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                    JOIN slot_has_product d ON c.id=d.pricing_id
                    where d.slot_id = $slot_id and c.id=$pricing_id
                    group by a.name";
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "slot"=>$data,
                                    
                                   
                    
                            ));
            
            
        }
        
        
        /**
         * This is tehe function that modifies the products on a slot
         */
        public function actionmodifyproductinaslot(){
            $model = new SlotHasProduct;
            
            $slot_id = $_REQUEST['slot_id'];
            $pricing_id = $_REQUEST['pricing_id'];
            $required_quantity = $_REQUEST['required_quantity'];
            
            if($model->isTheModificationOfThisProductASuccess($slot_id,$pricing_id,$required_quantity)){
                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => "This product was modified successfully",
                                   
                    
                            ));
            }else{
                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => "Attemppt to modify this product in the slot was not successful",
                                   
                    
                            ));
            }
            
            
            
            
        }
        
        
        /**
         * This is the function that removes a product from a slot
         */
        public function actionremovethisproductfromthisslot(){
            $model = new SlotHasProduct;
            
            $slot_id = $_REQUEST['slot_id'];
            $pricing_id = $_REQUEST['pricing_id'];
            
            if($model->isRemovalOfThisProductFromThisSlotASuccess($slot_id,$pricing_id)){
                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => "This product was removed from this slot successfully",
                                   
                    
                            ));
                
            }else{
                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => "Attemppt to remove this product from the slot was not successful",
                                   
                    
                            ));
                
            }
            
            
        }
        
        /**
         * This is the function that deplicates a slot
         */
        public function actionduplicateslot(){
            $model = new Slot;
            $original_slot_id = $_REQUEST['id'];
            $model->name = $_REQUEST['name'];
            if(isset($_REQUEST['description'])){
                 $model->description = $_REQUEST['description'];
            }
            $model->merchant_id = $_REQUEST['merchant_id'];
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
            //get all the prodducts or items of the original slot
            $products = $this->getAllTheProductsOfThisSlot($original_slot_id);
           
            if($model->save()){
                if($products != NULL){
                    foreach($products as $prod){
                        //insert this product to the slot
                        $this->addThisProductToThisSlot($model->id,$prod->pricing_id,$prod->required_quantity);
                    }
                    
                    
                    
                }
                header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => "This slot is created successfully")
                           );
            }else{
                 header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => "Validation issue: This slot was not created")
                           );
                
            }
            
            
            
        }
        
        /**
         * This is the function that retrieves all products in a slot
         */
        public function getAllTheProductsOfThisSlot($slot_id){
            $model = new SlotHasProduct;
            return $model->getAllTheProductsOfThisSlot($slot_id);
        }
        
        
        /**
         * This function list all slots
         */
        public function actionlistAllSlots(){
             $model = new Slot;
            
             $slots = Slot::model()->findAll();
                if($slots===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "slot" =>$slots,
                                   
                    
                            ));
                       
                }
            
        }
     
}
