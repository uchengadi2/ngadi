<?php

/**
 * This is the model class for table "user".
 *
 * The followings are the available columns in table 'user':
 * @property string $id
 * @property string $username
 * @property string $email
 * @property string $password
 * @property string $picture
 * @property string $status
 * @property string $name
 * @property integer $merchant_id
 * @property string $type
 * @property string $role
 * @property string $create_time
 * @property integer $create_user_id
 * @property string $update_time
 * @property integer $update_user_id
 */
class User extends CActiveRecord
{
	
    
        private $_identity;
        public $password_repeat;
        public $current_pass;
        /**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'user';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
                        array('password,password_repeat','required', 'on' => 'insert' ),
			array('username, email, status, name, type, role', 'required'),
			array('type_id, create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('username, email', 'length', 'max'=>100),
                         array('username', 'required', 'on' => 'insert'),
                        array('username, email', 'unique'),
			array('password, picture', 'length', 'max'=>60),
                        array('password', 'authenticate', 'on' => 'login'),
                        array('password, password_repeat', 'length', 'min'=>8, 'max'=>60, 'tooShort'=>'Your Password is less than eight(8) characters', 'tooLong'=>'Password cannot be greater than 60 characters'),
			 array('password, password_repeat', 'match', 'pattern'=>'/^.*(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[\d])(?=.*[\W]).*$/', 'message'=>'Password must have at least one capital letter, at least one number, at least one special character, and at least a lower case letter'),
                        array('status', 'length', 'max'=>8),
			array('name', 'length', 'max'=>250),
			array('type', 'length', 'max'=>10),
			array('role', 'length', 'max'=>64),
			array('create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, username, email, password, picture, status, name, type_id, type, role, create_time, create_user_id, update_time, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'username' => 'Username',
			'email' => 'Email',
			'password' => 'Password',
			'picture' => 'Picture',
			'status' => 'Status',
			'name' => 'Name',
			'merchant_id' => 'Merchant',
			'type' => 'Type',
			'role' => 'Role',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
			'update_time' => 'Update Time',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('username',$this->username,true);
		$criteria->compare('email',$this->email,true);
		$criteria->compare('password',$this->password,true);
		$criteria->compare('picture',$this->picture,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('merchant_id',$this->merchant_id);
		$criteria->compare('type',$this->type,true);
		$criteria->compare('role',$this->role,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return User the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        /*
	 * Authenticates the password.
	 * This is the 'authenticate' validator as declared in rules().
	 */
	//public function authenticate($attribute,$params)
       public function authenticate($attribute,$params)
	{
		if(!$this->hasErrors())
		{
			$this->_identity=new UserIdentity($this->username,$this->password);
			if(!$this->_identity->authenticate())
				$this->addError('password','Incorrect username or password.');
		}
	}
        
        
        /**
	 * Logs in the user using the given username and password in the model.
	 * @return boolean whether login is successful
	 */
	public function login()
	{
		if($this->_identity===null)
		{
			
                        $this->_identity=new UserIdentity($this->username,$this->password);
			$this->_identity->authenticate();
		}
		if($this->_identity->errorCode===UserIdentity::ERROR_NONE)
		{
			//$duration=$this->rememberMe ? 3600*24*30 : 0; // 30 days
			Yii::app()->user->login($this->_identity);
			return true;
		}
		else
			return false;
	}
        
        /*
         * Hash the password for security reasons
         */
        public function hashPassword($password){
            
            //return md5($password);
           /**
            if (CRYPT_STD_DES == 1) {
                return crypt($password, Yii::app()->params['encryptionKey_1']);
            }
            if (CRYPT_EXT_DES == 1) {
                 return crypt($password, Yii::app()->params['encryptionKey_2']);
            }
            if (CRYPT_MD5 == 1) {
                return crypt($password, Yii::app()->params['encryptionKey_3']);
            }
            if (CRYPT_BLOWFISH == 1) {
                return crypt($password, Yii::app()->params['encryptionKey_4']);
            }
            if (CRYPT_SHA256 == 1) {
                 return crypt($password, Yii::app()->params['encryptionKey_5']);
            }
            if (CRYPT_SHA512 == 1) {
                 return crypt($password, Yii::app()->params['encryptionKey_6']);
            }
            * 
            */
          $options = [
                
                'cost' => 11,
                'salt' => Yii::app()->params['encryptionKey_6']
            ];
            return password_hash($password,PASSWORD_BCRYPT, $options );
         
         
            
            
        }
        
        
        /**
         * Obtain the password validation for maximum length rules
         */
        
        public function getPasswordMaxLengthRule($password){
            
            foreach ($this->getValidators('password') as $validator) {
            if ($validator instanceof CStringValidator && $validator->max !== null) {
                 //echo 'this is the max length ' . $validator->max;
             
                if(is_string($password)){
                   
                        return(strlen($password)<=$validator->max);
                        
                    
                }
                
            }
            }
            
    }
    
    
      /**
         * Obtain the password validation for minimum length rules
         */
        
        public function getPasswordMinLengthRule($password){
            
            foreach ($this->getValidators('password') as $validator) {
            if ($validator instanceof CStringValidator && $validator->min !== null) {
                 //echo 'this is the max length ' . $validator->max;
             
                if(is_string($password)){
                   
                        return(strlen($password)>= $validator->min);
                        
                    
                }
                
            }
            }
            
    }
    
    
    /**
         * overwrite the beforeSave() function
         */
      
        public function beforeSave(){
            
            
                if(parent::beforeSave()){
                  if($this->password !== ''){
                      $pass = $this->hashPassword($this->password);
                      //$pass = md5($this->password);
                     $this->password = $pass;
                    return true;
                      
                  }elseif($this->password === ''){
                      
                      $this->password = $this->current_pass;
                      
                      return true;
                  }
                
                
            } else{
                
                return false;
            }
                
           
            
              
          
            
            
            
    }
       
       
    
    
    /**
         * Obtain the password validation for pattern rules
         */
        
        public function getPasswordCharacterPatternRule($password){
            
            foreach ($this->getValidators('password') as $validator) {
            if ($validator instanceof CRegularExpressionValidator && $validator->pattern !== null) {
                 //echo 'this is the max length ' . $validator->max;
             
                return(preg_match($validator->pattern,$password));
                   
                       
            }
            }
        } 
        
        
        
        
        /**
         * This is the function that determines the type and size of icon file
         */
        public function isIconTypeAndSizeLegal(){
            
           $size = []; 
            if(isset($_FILES['picture']['name'])){
                $tmpName = $_FILES['picture']['tmp_name'];
                $iconFileName = $_FILES['picture']['name'];    
                $iconFileType = $_FILES['picture']['type'];
                $iconFileSize = $_FILES['picture']['size'];
            } 
           if (isset($_FILES['picture'])) {
                $filename = $_FILES['picture']['tmp_name'];
                list($width, $height) = getimagesize($filename);
           }
      
         
           if(($iconFileType == 'image/png'|| $iconFileType == 'image/jpg' || $iconFileType == 'image/jpeg')){
              if($width>=1000 && $height>=1000){
                   return true;
              }else{
                  return false;
              }
               
            }else{
                return false;
            }
            
        }
        
        
        
     /**
         * This is the function that moves icons to its directory
         */
        public function moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename){
            
            if(isset($_FILES['picture']['name'])){
                        $tmpName = $_FILES['picture']['tmp_name'];
                        $iconName = $_FILES['picture']['name'];    
                        $iconType = $_FILES['picture']['type'];
                        $iconSize = $_FILES['picture']['size'];
                  
                   }
                    
                    if($icon_filename !== null) {
                        if($model->id === null){
                          //$iconFileName = $icon_filename;  
                          if($icon_filename != NULL){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }  
                          
                           // upload the icon file
                        if($iconName !== NULL){
                            	$iconPath = Yii::app()->params['users'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewIconFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != NULL){
                                if($this->removeTheExistingIconFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['users'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                                
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingIconFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheIconNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= User::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
                $directoryPath = "../ecommerce_images/users/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['picture'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isTheIconNotTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= User::model()->find($criteria);
                
                if($icon['picture'] ===NULL){
                    return false;
                }else{
                    return true;
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewIconFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= User::model()->find($criteria);
                
                if($icon['picture']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that retrieves the previous icon of the task in question
         */
        public function retrieveThePreviousIconName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = User::model()->find($criteria);
            
            
            return $icon['picture'];
            
            
        }
        
        
        /**
         * This is the function that gets the name of a country
         */
        public function getThisUserName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $user = User::model()->find($criteria); 
            
            return $user['name'];
        }
        
        
        /**
         * This is the function that confirms if the removal of a country name is a success
         */
        public function isTheRemovalOfUserImageASuccess($id){
            if($this->isThisUserWithPicture($id)){
                if($this->isTheRemovalOfTheUserPictureASuccess($id)){
                    return true;
                }else{
                    return false;
                }
            }else{
                return true;
            }
            
        }
        
        
        
        /**
         * This is the function that confirms if a country has a flag image
         */
        public function isThisUserWithPicture($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $user = User::model()->find($criteria); 
            
            if($user['picture']==NULL){
                return false;
            }else{
                return true;
            }
        }
        
        
        
        	 /**
         * This is the function that removes an existing video file
         */
        public function isTheRemovalOfTheUserPictureASuccess($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheIconNotTheDefault($id)){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= User::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
                $directoryPath = "../ecommerce_images/users/";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['picture'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
        
        
         /**
	 * Assign new role to a user 
	 */
	public function assignRoleToAUser($role, $userid)
	{
		
             //confirm that the role exist in the authitem table
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('authitem')
                    ->where('name' == $role);
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    //confirm if the user aleady had been assigned a role before
                    $cmd =Yii::app()->db->createCommand();
                        $cmd->select('COUNT(*)')
                        ->from('authassignment')
                         ->where('userid' == $userid);
                    $result1 = $cmd->queryScalar();
                    
                     if($result1 > 0){
                         //delete the previous role(s) of the user and insert the new role
                          $cmd->delete('authassignment', 'userid=:id', array(':id'=>$userid ));
                         
                         
                     }
                     $cmd->insert('authassignment',
                                        array(
                                           'userid'=>$userid,
                                           'itemname'=>$role,
                                          
                     ));
                   
                    return true;
                    
                    
                }else{
                  
                    return false;
                }
         
               
	}
        
        
        
        
         /**
         * This is the function that determines if a user is already existing on the platform
         */
        public function isThisUserAlreadyExistingOnThePlatform($model){
           if($this->isThisUserEmailAlreadyUsedOnThePlatform($model->email)){
                return true;
            }else{
                return false;
            }
           
        }
        
        
        
         /**
         * This is the function that confirms if a user's email had already been used on the platform
         */
        public function isThisUserEmailAlreadyUsedOnThePlatform($email){
            if($email !=null){
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user')
                    ->where("email = '$email'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            } 
            
        }
        
        
        
        /**
	 * delete a role assigned to a user 
	 */
	public function deleteRoleAssignedToAUser($role, $userid)
	{
            //determine if the role actually was assigned to the user
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('authassignment')
                    ->where('itemname' == $role and 'userid'==$userid);
                $result = $cmd->queryScalar();
                
                if($result > 0){
                   
                    return true;
                }else{
                 
                    return false;
                    
                }
                
		
             
               
	}
        
        
        
        /**
         * This is the function that retrieves the merchant id of a user
         */
        public function getTheMerchantIdOfThisUser($user_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id and type=:type';
            $criteria->params = array(':id'=>$user_id,':type'=>"merchant");
            $user = User::model()->find($criteria); 
            
            return $user['type_id'];
        }
        
        
        
         /**
         * This is the function that retrieves the merchant id of a user
         */
        public function getTheContractorIdOfThisUser($user_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id and type=:type';
            $criteria->params = array(':id'=>$user_id,':type'=>"contractor");
            $user = User::model()->find($criteria); 
            
            return $user['type_id'];
        }
       
        
        /**
         * This is the function that gets the name of a user
         */
        public function getTheNameOfThisUser($user_id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$user_id);
            $user = User::model()->find($criteria); 
            
            return $user['name'];
        }
        
        
        /**
         * This is the function that retrieves the email address of a user
         */
        public function getTheEmailAddressOfThisUser($user_id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$user_id);
            $user = User::model()->find($criteria); 
            
            return $user['email'];
        }
        
        
        /**
         * This is the function that updates a user's detail
         */
        public function isTheUserModificationASuccess($id,$type,$type_id,$status,$name,$picture){
            
            $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('user',
                                  array(
                                    'status'=>$status,
                                    'type'=>$type,
                                    'type_id'=>$type_id,
                                    'name'=>$name,
                                    'picture'=>$picture
           
                            ),
                     ("id=$id"));
            
            if($result>0){
                return true;
            }else{
                return false;
            }
            
            
        }
        
}
