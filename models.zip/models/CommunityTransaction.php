<?php

/**
 * This is the model class for table "community_transaction".
 *
 * The followings are the available columns in table 'community_transaction':
 * @property string $id
 * @property string $community_id
 * @property string $user_id
 * @property string $payment_term_requested
 * @property string $payment_status
 * @property integer $slot_quantity_purchased
 * @property string $address_of_delivery
 * @property integer $city_of_delivery
 * @property string $date_enrolled
 * @property integer $sequence_number
 * @property integer $remaining_number_of_slot_before_activation
 * @property integer $estimated_number_of_members_required_before_activation
 * @property string $delivery_status
 * @property string $remark
 */
class CommunityTransaction extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'community_transaction';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('community_id, user_id, payment_term_requested, payment_status, slot_quantity_purchased, remaining_number_of_slot_before_activation, estimated_number_of_members_required_before_activation', 'required'),
			array('slot_quantity_purchased, city_of_delivery, sequence_number, remaining_number_of_slot_before_activation, estimated_number_of_members_required_before_activation', 'numerical', 'integerOnly'=>true),
			array('community_id, user_id, payment_status', 'length', 'max'=>10),
			array('payment_term_requested', 'length', 'max'=>15),
			array('address_of_delivery, remark', 'length', 'max'=>250),
			array('delivery_status', 'length', 'max'=>11),
			array('date_enrolled', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, community_id, user_id, payment_term_requested, payment_status, slot_quantity_purchased, address_of_delivery, city_of_delivery, date_enrolled, sequence_number, remaining_number_of_slot_before_activation, estimated_number_of_members_required_before_activation, delivery_status, remark', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'community_id' => 'Community',
			'user_id' => 'User',
			'payment_term_requested' => 'Payment Term Requested',
			'payment_status' => 'Payment Status',
			'slot_quantity_purchased' => 'Slot Quantity Purchased',
			'address_of_delivery' => 'Address Of Delivery',
			'city_of_delivery' => 'City Of Delivery',
			'date_enrolled' => 'Date Enrolled',
			'sequence_number' => 'Sequence Number',
			'remaining_number_of_slot_before_activation' => 'Remaining Number Of Slot Before Activation',
			'estimated_number_of_members_required_before_activation' => 'Estimated Number Of Members Required Before Activation',
			'delivery_status' => 'Delivery Status',
			'remark' => 'Remark',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('community_id',$this->community_id,true);
		$criteria->compare('user_id',$this->user_id,true);
		$criteria->compare('payment_term_requested',$this->payment_term_requested,true);
		$criteria->compare('payment_status',$this->payment_status,true);
		$criteria->compare('slot_quantity_purchased',$this->slot_quantity_purchased);
		$criteria->compare('address_of_delivery',$this->address_of_delivery,true);
		$criteria->compare('city_of_delivery',$this->city_of_delivery);
		$criteria->compare('date_enrolled',$this->date_enrolled,true);
		$criteria->compare('sequence_number',$this->sequence_number);
		$criteria->compare('remaining_number_of_slot_before_activation',$this->remaining_number_of_slot_before_activation);
		$criteria->compare('estimated_number_of_members_required_before_activation',$this->estimated_number_of_members_required_before_activation);
		$criteria->compare('delivery_status',$this->delivery_status,true);
		$criteria->compare('remark',$this->remark,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return CommunityTransaction the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
