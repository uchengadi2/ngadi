<?php

/**
 * This is the model class for table "community_transaction".
 *
 * The followings are the available columns in table 'community_transaction':
 * @property string $id
 * @property string $community_id
 * @property integer $user_id
 * @property string $payment_term_requested
 * @property string $payment_status
 * @property integer $slot_quantity_purchased
 * @property string $address_of_delivery
 * @property integer $city_of_delivery
 * @property string $date_enrolled
 * @property integer $sequence_number
 * @property integer $remaining_number_of_slot_before_activation
 * @property integer $estimated_number_of_members_required_before_activation
 * @property string $delivery_status
 * @property string $remark
 * @property string $subscription_type
 * @property string $subscription_end_date
 * @property string $buyer_name
 * @property string $buyer_mobile_number
 * @property string $buyer_email_address
 * @property string $delivery_preference
 * @property double $total_cost_of_delivery
 * @property string $recipient_name
 * @property string $recipient_mobile_number
 * @property double $total_slot_cost
 * @property double $grand_cost
 */
class CommunityTransaction extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'community_transaction';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('community_id, payment_term_requested, payment_status, slot_quantity_purchased, remaining_number_of_slot_before_activation, estimated_number_of_members_required_before_activation', 'required'),
			array('user_id, slot_quantity_purchased, sequence_number, remaining_number_of_slot_before_activation, estimated_number_of_members_required_before_activation', 'numerical', 'integerOnly'=>true),
			array('total_cost_of_delivery, total_slot_cost, grand_cost', 'numerical'),
			array('community_id, payment_status', 'length', 'max'=>10),
			array('payment_term_requested', 'length', 'max'=>15),
			array('address_of_delivery, remark, buyer_name, buyer_mobile_number, buyer_email_address, delivery_preference, recipient_name, recipient_mobile_number', 'length', 'max'=>250),
			array('delivery_status, subscription_type', 'length', 'max'=>11),
			array('date_enrolled, subscription_end_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, community_id, user_id, payment_term_requested, payment_status, slot_quantity_purchased, address_of_delivery, city_of_delivery, date_enrolled, sequence_number, remaining_number_of_slot_before_activation, estimated_number_of_members_required_before_activation, delivery_status, remark, subscription_type, subscription_end_date, buyer_name, buyer_mobile_number, buyer_email_address, delivery_preference, total_cost_of_delivery, recipient_name, recipient_mobile_number, total_slot_cost, grand_cost', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'community_id' => 'Community',
			'user_id' => 'User',
			'payment_term_requested' => 'Payment Term Requested',
			'payment_status' => 'Payment Status',
			'slot_quantity_purchased' => 'Slot Quantity Purchased',
			'address_of_delivery' => 'Address Of Delivery',
			'city_of_delivery' => 'City Of Delivery',
			'date_enrolled' => 'Date Enrolled',
			'sequence_number' => 'Sequence Number',
			'remaining_number_of_slot_before_activation' => 'Remaining Number Of Slot Before Activation',
			'estimated_number_of_members_required_before_activation' => 'Estimated Number Of Members Required Before Activation',
			'delivery_status' => 'Delivery Status',
			'remark' => 'Remark',
			'subscription_type' => 'Subscription Type',
			'subscription_end_date' => 'Subscription End Date',
			'buyer_name' => 'Buyer Name',
			'buyer_mobile_number' => 'Buyer Mobile Number',
			'buyer_email_address' => 'Buyer Email Address',
			'delivery_preference' => 'Delivery Preference',
			'total_cost_of_delivery' => 'Total Cost Of Delivery',
			'recipient_name' => 'Recipient Name',
			'recipient_mobile_number' => 'Recipient Mobile Number',
			'total_slot_cost' => 'Total Slot Cost',
			'grand_cost' => 'Grand Cost',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('community_id',$this->community_id,true);
		$criteria->compare('user_id',$this->user_id);
		$criteria->compare('payment_term_requested',$this->payment_term_requested,true);
		$criteria->compare('payment_status',$this->payment_status,true);
		$criteria->compare('slot_quantity_purchased',$this->slot_quantity_purchased);
		$criteria->compare('address_of_delivery',$this->address_of_delivery,true);
		$criteria->compare('city_of_delivery',$this->city_of_delivery);
		$criteria->compare('date_enrolled',$this->date_enrolled,true);
		$criteria->compare('sequence_number',$this->sequence_number);
		$criteria->compare('remaining_number_of_slot_before_activation',$this->remaining_number_of_slot_before_activation);
		$criteria->compare('estimated_number_of_members_required_before_activation',$this->estimated_number_of_members_required_before_activation);
		$criteria->compare('delivery_status',$this->delivery_status,true);
		$criteria->compare('remark',$this->remark,true);
		$criteria->compare('subscription_type',$this->subscription_type,true);
		$criteria->compare('subscription_end_date',$this->subscription_end_date,true);
		$criteria->compare('buyer_name',$this->buyer_name,true);
		$criteria->compare('buyer_mobile_number',$this->buyer_mobile_number,true);
		$criteria->compare('buyer_email_address',$this->buyer_email_address,true);
		$criteria->compare('delivery_preference',$this->delivery_preference,true);
		$criteria->compare('total_cost_of_delivery',$this->total_cost_of_delivery);
		$criteria->compare('recipient_name',$this->recipient_name,true);
		$criteria->compare('recipient_mobile_number',$this->recipient_mobile_number,true);
		$criteria->compare('total_slot_cost',$this->total_slot_cost);
		$criteria->compare('grand_cost',$this->grand_cost);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return CommunityTransaction the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        

 /**
         * This is the function that calculates a committee members enrollment srquence number
         */
        public function getTheSequenceNumberOfThisTransaction($community_id,$quantity){
            
            $max_sequence_number = $this->getTheMaximunSequenceNumberOfThisCommunity($community_id);
            
            $next_sequence_number = $max_sequence_number + $quantity;
            
            return $next_sequence_number;
            
            
        }
        
        /**
         * this is the function that gets the maximum sequence number in a community
         */
        public function getTheMaximunSequenceNumberOfThisCommunity($community_id){
            
            if($this->isThisCommunityWithAnyMember($community_id)){
                $seqno = 0;
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='community_id=:id';
                $criteria->params = array(':id'=>$community_id);
                $seqences = CommunityTransaction::model()->findAll($criteria);
            
           
             
             if($seqences == null){
                 return $seqno;
             }else{
                 foreach($seqences as $seq){
                     if($seq['sequence_number']>$seqno){
                         $seqno = $seq['sequence_number'];
                     }
                 }
                 return $seqno;
             }
                
                
            }else{
                return 0;
                
            }
            
            
        }
        
        /**
         * This is the function that confirms if a commuity has at least a member
         */
        public function isThisCommunityWithAnyMember($community_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('community_transaction')
                    ->where("community_id = $community_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
        
        /**
         * This is the function that computes the remaining number slots before activation
         */
        public function getTheNumberOfRemainingSlotsBeforeActivation($community_id,$sequence_number){
            $model = new BuyerCommunity;
            //get the community minimum number of slot purchases required before activation
            $min_before_activation = $model->getTheMinimumNumberOfSlotPurchaseRequiredBeforeActivationInThisCommunity($community_id);
            $diff = (int)$min_before_activation - (int)$sequence_number;
            if($diff == 0){
                return 0;
            }else if($diff<0){
                return 0;
            }else{
                return $diff;
            }
           
           
        }
        
        
        
        /**
         * This is the function that gets the minimum remianing number of members required before activation
         */
        public function getTheRemainingNumberOfMembersBeforeActivation($community_id,$sequence_number){
            $model = new BuyerCommunity;
            $required_community_min_membership = $model->getTheRequiredCommunityMembershipNumberOfThisCommunity($community_id);
            $diff = (int)$required_community_min_membership - (int)$sequence_number;
            if($diff == 0){
                return 0;
            }else if($diff<0){
                return 0;
            }else{
                return $diff;
            }
            
        }
        
        
        /**
         * This is the function that gets the total number of currently enrolled members in a community
         */
        public function getTheNumberOfCurrentlyEnrolledMembersInThisCommunity($community_id){
         return  $this->getTheMaximunSequenceNumberOfThisCommunity($community_id);
            
        }
}
