<?php

/**
 * This is the model class for table "inventory".
 *
 * The followings are the available columns in table 'inventory':
 * @property string $id
 * @property string $product_id
 * @property string $warehouse_id
 * @property double $quantity
 * @property integer $quantity_measurement_type_id
 * @property string $create_time
 * @property string $update_time
 * @property integer $create_user_id
 * @property integer $update_user_id
 */
class Inventory extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'inventory';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('product_id, warehouse_id, quantity_measurement_type_id', 'required'),
			array('quantity_measurement_type_id, create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('quantity', 'numerical'),
			array('product_id, warehouse_id', 'length', 'max'=>10),
			array('create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, product_id, warehouse_id, quantity, quantity_measurement_type_id, create_time, update_time, create_user_id, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'product_id' => 'Product',
			'warehouse_id' => 'Warehouse',
			'quantity' => 'Quantity',
			'quantity_measurement_type_id' => 'Quantity Measurement Type',
			'create_time' => 'Create Time',
			'update_time' => 'Update Time',
			'create_user_id' => 'Create User',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('product_id',$this->product_id,true);
		$criteria->compare('warehouse_id',$this->warehouse_id,true);
		$criteria->compare('quantity',$this->quantity);
		$criteria->compare('quantity_measurement_type_id',$this->quantity_measurement_type_id);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Inventory the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that confirms if a product is already assigned to a warehouse
         */
        public function isThisProductAlreadyAssignedToThisWarehouse($product_id,$warehouse_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('inventory')
                    ->where("product_id = $product_id and warehouse_id=$warehouse_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        
         /**
         * This is the function that confirms if a the removal of product from a warehouse is a success
         */
        public function isTheRemovalOfThisProductFromThisWarehouseASuccess($product_id,$warehouse_id){
             $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('inventory', 'product_id=:prodid and warehouse_id=:wareid', array(':prodid'=>$product_id,':wareid'=>$warehouse_id));
            
                if($result>0){
                    return true;
                    
                }else{
                    return false;
                }
        }
        
        
        
        /**
         * This is the function that retrieves an inventory id 
         */
        public function getTheInventoryIdOfThisInventory($product_id,$warehouse_id){
            $model = new Inventory;
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='warehouse_id=:wareid and product_id=:prodid';
              $criteria->params = array(':wareid'=>$warehouse_id,':prodid'=>$product_id);
              $inventory= Inventory::model()->find($criteria);
              
              if($inventory == null){
                  return null;
              }
              
              return $inventory['id'];
        }
        
        
         /**
         * This is the function that list all product in a warehouse
         */
        public function getAllProductsInThisWarehouse($warehouse_id){
            $target = [];
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='warehouse_id=:wareid';
              $criteria->params = array(':wareid'=>$warehouse_id);
              $products= Inventory::model()->findAll($criteria);
              foreach($products as $prod){
                  $target[] = $prod['product_id'];
              }
              
              return $target;
              
        }
        
        
        /**
         * This is the function that gets all the inventory ids associated with product
         */
        public function getAllTheInventoryIdsAssociatedWithProducts($product_id){
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='product_id=:prodid';
              $criteria->params = array(':prodid'=>$product_id);
              $inventory= Inventory::model()->findAll($criteria);
              
              $target = [];
              foreach($inventory as $inv){
                  $target[] =$inv['id'];
              }
              return $target;        
              
        }
        
        
        
         /**
         * This is the function that list all warehouses that is storing this product
         */
        public function getAllWarehouseThatIsStoringThisProduct($product_id){
            $target = [];
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='product_id=:prodid';
              $criteria->params = array(':prodid'=>$product_id);
              $warehouses= Inventory::model()->findAll($criteria);
              foreach($warehouses as $prod){
                  $target[] = $prod['warehouse_id'];
              }
              
              return $target;
              
        }
        
        
         /**
         * This is the function retrieves a product for a pricing
         */
        public function getTheProductWithThisPricing($inventory_id){
            $model = new Inventory;
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$inventory_id);
            $inventory= Inventory::model()->find($criteria);
            
            return $inventory['product_id'];
        }
        
        
         /**
         * This is the function retrieves a product warehouse  for a pricing
         */
        public function getTheWarehouseForThisPricing($inventory_id){
            $model = new Inventory;
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$inventory_id);
            $inventory= Inventory::model()->find($criteria);
            
            return $inventory['warehouse_id'];
        }
}
