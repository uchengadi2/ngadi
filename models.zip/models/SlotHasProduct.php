<?php

/**
 * This is the model class for table "slot_has_product".
 *
 * The followings are the available columns in table 'slot_has_product':
 * @property string $slot_id
 * @property string $pricing_id
 * @property integer $required_quantity
 */
class SlotHasProduct extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'slot_has_product';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('slot_id, pricing_id, required_quantity', 'required'),
			array('required_quantity', 'numerical', 'integerOnly'=>true),
			array('slot_id, pricing_id', 'length', 'max'=>10),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('slot_id, pricing_id, required_quantity', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'slot_id' => 'Slot',
			'pricing_id' => 'Pricing',
			'required_quantity' => 'Required Quantity',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('slot_id',$this->slot_id,true);
		$criteria->compare('pricing_id',$this->pricing_id,true);
		$criteria->compare('required_quantity',$this->required_quantity);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return SlotHasProduct the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that adds a product to a slot
         */
        public function addThisProductToThisSlot($id,$pricing_id,$required_quantity){
            $this->slot_id = $id;
            $this->pricing_id = $pricing_id;
            $this->required_quantity = $required_quantity;
            
            if($this->save()){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that confirms if a product is already in a slot
         */
        public function isProductPricingAlreadyInThisSlot($slot_id,$pricing_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('slot_has_product')
                    ->where("slot_id =$slot_id and pricing_id=$pricing_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that effects product modification in a slot
         */
        public function isTheModificationOfThisProductASuccess($slot_id,$pricing_id,$required_quantity){
            $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('slot_has_product',
                                  array(
                                    'required_quantity'=>$required_quantity, 
                                   
                            ),
                ("slot_id=$slot_id and pricing_id=$pricing_id")
			
                        );
               if($result>0){
                   return true;
               }else{
                   return false;
               }
        }
        
        
        /**
         * This is the function that removes a product from a slot
         */
        public function isRemovalOfThisProductFromThisSlotASuccess($slot_id,$pricing_id){
             $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('slot_has_product', 'slot_id=:slotid and pricing_id=:pricingid', array(':slotid'=>$slot_id,':pricingid'=>$pricing_id));
            
                if($result>0){
                    return true;
                    
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that retrieves all products in a slot
         */
        public function getAllTheProductsOfThisSlot($slot_id){
              
              $target = [];
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='slot_id=:slotid';
              $criteria->params = array(':slotid'=>$slot_id);
              $products= SlotHasProduct::model()->findAll($criteria);
              
              foreach($products as $pro){
                  $target[] = $pro;
              }
              return $target;
        }
        
        /**
         * This is the function that commputes the cost per slots
         */
        public function computeTheCostOfOneSlot($slot_id,$estimated_minimum_number_of_members_required){
            $model = new Pricing; 
            $sum = 0;   
            //get all products in this slot
            $products = $this->getAllTheProductsOfThisSlot($slot_id);
            foreach($products as $prod){
                $quantity = $prod['required_quantity'];
                $price_per_unit = (double)$model->getThePriceOfThisPricingId($prod['pricing_id']) * $quantity;
                $bulk_discount = (double)$model->getTheDiscountRateOfThisPricing($prod['pricing_id'],$estimated_minimum_number_of_members_required);
                $sum = $sum + (($price_per_unit -($price_per_unit * $bulk_discount/100))) ;
            }
            return round($sum,2);
        }
        
        
        /**
         * This is the function that computes the delivering cost per slot 
         */
        public function computeTheCostOfDeliveryPerSlot($slot_id,$minimum_purchase_per_member,$delivery_preference,$place_id,$city_id,$state_id){
            $model = new Place;
             //get the weight of this slot
             $slot_weight = $this->getTheTotalWeightOfThisSlot($slot_id);
                
            if($delivery_preference == "decentralized"){
                return "varies";
            }else if($delivery_preference == "centralized"){
                //get the standard delivery cost to this city
                $city_standard = $this->getThisCityData($city_id);
                $city_diff = $slot_weight - $city_standard['intra_city_maximum_base_weight'];
                if($city_diff<=0){
                    return (double)$city_standard['intra_city_base_rate'];
                }else if($city_diff>0){
                    $delivery_cost = $city_standard['intra_city_base_rate'] + ($city_diff * $city_standard['intra_city_per_additional_kg']);
                    return (double)round($delivery_cost,2);
                }
                
                
            }else if($delivery_preference == "within_a_place"){
               
                //get the standard delivery cost to this place
                $standard = $model->getThisPlaceData($place_id);
                $diff = $slot_weight - $standard['intra_place_maximum_base_weight'];
                if($diff<=0){
                    return (double)$standard['intra_place_base_rate'];
                }else if($diff>0){
                    $delivery_cost = $standard['intra_place_base_rate'] + ($diff * $standard['intra_place_per_additional_kg']);
                    return (double)round($delivery_cost,2);
                }
                
            }
        }
        
        
        /**
         * This is the function that gets the total weight of a slot
         */
        public function getTheTotalWeightOfThisSlot($slot_id){
            $model = new Pricing;
            $sum = 0;
            
            //get all the products in this slots
            $products = $this->getAllTheProductsOfThisSlot($slot_id);
            foreach($products as $prod){
                //get the product weight in kg
                $sum = $sum + $model->getTheProductPricingInKg($prod['pricing_id'],$prod['required_quantity']);
            }
            return (double)$sum;
        }
        
        
        /**
         * This is the function that gets a city's data
         */
        public function getThisCityData($city_id){
            $model = new City;
            return $model->getThisCityData($city_id);
        }
}
