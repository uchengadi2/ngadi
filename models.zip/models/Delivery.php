<?php

/**
 * This is the model class for table "delivery".
 *
 * The followings are the available columns in table 'delivery':
 * @property string $id
 * @property string $package_id
 * @property string $status
 * @property string $remark
 * @property integer $delivered_by
 * @property string $date_of_delivery
 * @property integer $delivery_confirmed_by
 * @property string $date_of_delivery_confirmation
 * @property integer $package_confirmed_by
 * @property string $date_of_package_confirmation
 */
class Delivery extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'delivery';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('package_id, status', 'required'),
			array('delivered_by, delivery_confirmed_by, package_confirmed_by', 'numerical', 'integerOnly'=>true),
			array('package_id', 'length', 'max'=>10),
			array('status', 'length', 'max'=>9),
			array('remark, date_of_delivery, date_of_delivery_confirmation, date_of_package_confirmation', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, package_id, status, remark, delivered_by, date_of_delivery, delivery_confirmed_by, date_of_delivery_confirmation, package_confirmed_by, date_of_package_confirmation', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'package_id' => 'Package',
			'status' => 'Status',
			'remark' => 'Remark',
			'delivered_by' => 'Delivered By',
			'date_of_delivery' => 'Date Of Delivery',
			'delivery_confirmed_by' => 'Delivery Confirmed By',
			'date_of_delivery_confirmation' => 'Date Of Delivery Confirmation',
			'package_confirmed_by' => 'Package Confirmed By',
			'date_of_package_confirmation' => 'Date Of Package Confirmation',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('package_id',$this->package_id,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('remark',$this->remark,true);
		$criteria->compare('delivered_by',$this->delivered_by);
		$criteria->compare('date_of_delivery',$this->date_of_delivery,true);
		$criteria->compare('delivery_confirmed_by',$this->delivery_confirmed_by);
		$criteria->compare('date_of_delivery_confirmation',$this->date_of_delivery_confirmation,true);
		$criteria->compare('package_confirmed_by',$this->package_confirmed_by);
		$criteria->compare('date_of_package_confirmation',$this->date_of_package_confirmation,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Delivery the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * this is the function that confirms if a package is already on a delivery process
         */
        public function isThisPackageAlreadyForDelivery($package_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('delivery')
                    ->where("package_id = $package_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
}
