<?php

/**
 * This is the model class for table "buyer_community".
 *
 * The followings are the available columns in table 'buyer_community':
 * @property string $id
 * @property string $name
 * @property string $description
 * @property string $code
 * @property string $slot_id
 * @property string $delivery_preference
 * @property string $address_of_centralized_delivery
 * @property integer $place_id
 * @property string $status
 * @property integer $minimum_purchase_per_member
 * @property integer $estimated_minimum_number_of_members_required
 * @property integer $minimum_purchases_required_before_activation
 * @property string $date_of_activation
 * @property string $start_date_of_delivery
 * @property string $last_date_of_delivery
 * @property double $delivery_cost_per_slot
 * @property string $terms_and_condition
 * @property string $date_created
 * @property string $last_date_of_membership_enrollment
 * @property string $payment_terms
 * @property string $preferred_hybrid_payment
 * @property string $hybrid_payment_must_exclude
 * @property integer $created_by
 */
class BuyerCommunity extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'buyer_community';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('slot_id, delivery_preference, status, minimum_purchase_per_member, estimated_minimum_number_of_members_required, minimum_purchases_required_before_activation, payment_terms', 'required'),
			array('place_id, minimum_purchase_per_member, estimated_minimum_number_of_members_required, minimum_purchases_required_before_activation', 'numerical', 'integerOnly'=>true),
			array('delivery_cost_per_slot', 'numerical'),
			array('name, description, code, address_of_centralized_delivery', 'length', 'max'=>250),
			array('slot_id', 'length', 'max'=>10),
			array('delivery_preference', 'length', 'max'=>14),
			array('status', 'length', 'max'=>6),
			array('payment_terms, preferred_hybrid_payment, hybrid_payment_must_exclude', 'length', 'max'=>15),
			array('date_of_activation, start_date_of_delivery, last_date_of_delivery, terms_and_condition, date_created, last_date_of_membership_enrollment', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name, description, code, slot_id, delivery_preference, address_of_centralized_delivery, place_id, status, minimum_purchase_per_member, estimated_minimum_number_of_members_required, minimum_purchases_required_before_activation, date_of_activation, start_date_of_delivery, last_date_of_delivery, delivery_cost_per_slot, terms_and_condition, date_created, last_date_of_membership_enrollment, payment_terms, preferred_hybrid_payment, hybrid_payment_must_exclude', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'description' => 'Description',
			'code' => 'Code',
			'slot_id' => 'Slot',
			'delivery_preference' => 'Delivery Preference',
			'address_of_centralized_delivery' => 'Address Of Centralized Delivery',
			'place_id' => 'Place',
			'status' => 'Status',
			'minimum_purchase_per_member' => 'Minimum Purchase Per Member',
			'estimated_minimum_number_of_members_required' => 'Estimated Minimum Number Of Members Required',
			'minimum_purchases_required_before_activation' => 'Minimum Purchases Required Before Activation',
			'date_of_activation' => 'Date Of Activation',
			'start_date_of_delivery' => 'Start Date Of Delivery',
			'last_date_of_delivery' => 'Last Date Of Delivery',
			'delivery_cost_per_slot' => 'Delivery Cost Per Slot',
			'terms_and_condition' => 'Terms And Condition',
			'date_created' => 'Date Created',
			'last_date_of_membership_enrollment' => 'Last Date Of Membership Enrollment',
			'payment_terms' => 'Payment Terms',
			'preferred_hybrid_payment' => 'Preferred Hybrid Payment',
			'hybrid_payment_must_exclude' => 'Hybrid Payment Must Exclude',
			'created_by' => 'Created By',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('code',$this->code,true);
		$criteria->compare('slot_id',$this->slot_id,true);
		$criteria->compare('delivery_preference',$this->delivery_preference,true);
		$criteria->compare('address_of_centralized_delivery',$this->address_of_centralized_delivery,true);
		$criteria->compare('place_id',$this->place_id);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('minimum_purchase_per_member',$this->minimum_purchase_per_member);
		$criteria->compare('estimated_minimum_number_of_members_required',$this->estimated_minimum_number_of_members_required);
		$criteria->compare('minimum_purchases_required_before_activation',$this->minimum_purchases_required_before_activation);
		$criteria->compare('date_of_activation',$this->date_of_activation,true);
		$criteria->compare('start_date_of_delivery',$this->start_date_of_delivery,true);
		$criteria->compare('last_date_of_delivery',$this->last_date_of_delivery,true);
		$criteria->compare('delivery_cost_per_slot',$this->delivery_cost_per_slot);
		$criteria->compare('terms_and_condition',$this->terms_and_condition,true);
		$criteria->compare('date_created',$this->date_created,true);
		$criteria->compare('last_date_of_membership_enrollment',$this->last_date_of_membership_enrollment,true);
		$criteria->compare('payment_terms',$this->payment_terms,true);
		$criteria->compare('preferred_hybrid_payment',$this->preferred_hybrid_payment,true);
		$criteria->compare('hybrid_payment_must_exclude',$this->hybrid_payment_must_exclude,true);
		$criteria->compare('created_by',$this->created_by);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return BuyerCommunity the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        
      
        /**
         * This is the function that generates community code for a merchant 
         */
        public function generateTheCodeForThisCommunity($merchant_id){
            $model = new Merchant;
            $merchant_code = $model->getTheCodeOfThisMerchant($merchant_id);
            //get the next available number of this merchant
            $next_merchant_code_number = $model->getTheNextMerchantCodeNumber($merchant_id);
            
            if(strlen("$next_merchant_code_number")==1){
                    $next_code_numbering = str_pad($next_merchant_code_number, 4, "0", STR_PAD_LEFT);
                }else if(strlen("$next_merchant_code_number")==2){
                    $next_code_numbering = str_pad($next_merchant_code_number, 3, "0", STR_PAD_LEFT);
                }else if(strlen("$next_merchant_code_number")==3){
                    $next_code_numbering = str_pad($next_merchant_code_number, 2, "0", STR_PAD_LEFT);
                }else if(strlen("$next_merchant_code_number")>=4){
                    $next_code_numbering = $next_merchant_code_number;
                }
                
                $code = "$merchant_code$next_code_numbering";
                
                return $code;
            
        }
        
        
         /**
         * This is the function that confirms if code exist
         */
        public function isCodeExist($code){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('buyer_community')
                    ->where("code = '$code'");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
         /**
         * This is the function that retrieves the status of a code
         */
        public function getThisCodeStatus($code){
            //get the expirt date of this code
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='code=:code';
            $criteria->params = array(':code'=>"$code");
            $thiscode = BuyerCommunity::model()->find($criteria);
            
            return $thiscode['status'];
        }
        
        
         /**
         * This is the function that determines if a code had expired
         */
        public function isCodeExpired($code){
            //get the expirt date of this code
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='code=:code';
            $criteria->params = array(':code'=>"$code");
            $code = BuyerCommunity::model()->find($criteria);
            
            if($this->isThisCodeActive($code['last_date_of_membership_enrollment'])){
                return false;
            }else{
                return true;
            }
        }
        
        
        /**
         * This is the function that verifies if a code is still valid
         */
        public function isThisCodeActive($last_date_of_membership_enrollment){
            $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
           $expiry = getdate(strtotime($last_date_of_membership_enrollment));
            //getdate(date("Y-m-d H:i:s", strtotime($date_of_expiry))); 
            $day = $today['mday'];
            $month = $today['mon'];
            $year = $today['year'];
            
            if($expiry['year']-$year<0){
                return false;
            }else if($expiry['year']-$year==0){
                if($expiry['mon']-$month<0){
                    return false;
                }else if($expiry['mon']-$month >0){
                    return true;
                }else if($expiry['mon']-$month ==0){    
                   if($expiry['mday']-$day<0){
                       return false;
                   }else{
                       return true;
                   }
                }else{
                    return true;
                }
            }else{
                return true;
            }
            
           
        }
        
        
        /**
         * This is the function that retrieves the community id of a community using its code 
         */
        public function getTheIdOfThisCommunityWithThisCode($code){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="code=:code and status='open'";
            $criteria->params = array(':code'=>"$code");
            $code = BuyerCommunity::model()->find($criteria);
            
            return $code['id'];
        }
        
        
        /**
         * This is the function that retrieves the slot id of a community
         */
        public function getTheSlotIdCurrentlyAttachedToThisCommunity($code){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="code=:code and status='open'";
            $criteria->params = array(':code'=>"$code");
            $code = BuyerCommunity::model()->find($criteria);
            
            return $code['slot_id'];
        }
        
        
          /**
         * This is the function that gets the estimated number of  members rquired before activation
         */
        public function getTheRequiredCommunityMembershipNumberOfThisCommunity($community_id){
           $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id and status=:status';
            $criteria->params = array(':id'=>$community_id,':status'=>'open');
            $community = BuyerCommunity::model()->find($criteria);
            
            return $community['minimum_purchases_required_before_activation'];
            
            
        }
        
        
         /**
         * This is the function that gets the minimum number of slots sales required before activation
         */
        public function getTheMinimumNumberOfSlotPurchaseRequiredBeforeActivationInThisCommunity($community_id){
           $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$community_id);
            $community = BuyerCommunity::model()->find($criteria);
            
            $estimate_slot_min =  (double)$community['estimated_minimum_number_of_members_required']/(int)$community['minimum_purchase_per_member'];
            
            return ceil($estimate_slot_min);
            
            
        } 
        
        
       
        
}
