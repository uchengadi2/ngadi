<?php

/**
 * This is the model class for table "contractor".
 *
 * The followings are the available columns in table 'contractor':
 * @property string $id
 * @property string $name
 * @property string $email
 * @property string $address
 * @property string $phone_number
 * @property string $banker
 * @property string $account_number
 * @property string $account_title
 * @property string $bank_swift_code
 * @property string $tax_identification_pin
 * @property string $vat_number
 * @property string $contact_person_name
 * @property string $contact_person_mobile_number
 * @property string $contact_person_email
 * @property string $contractorid
 * @property string $contractor_type
 * @property string $description
 * @property string $create_time
 * @property integer $create_user_id
 * @property string $update_time
 * @property integer $update_user_id
 *
 * The followings are the available model relations:
 * @property City[] $cities
 * @property PackageForContractor[] $packageForContractors
 */
class Contractor extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'contractor';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('name, email, contact_person_name, contact_person_email, contractor_type', 'required'),
			array('create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('name, email, address, banker, contact_person_name, contact_person_email', 'length', 'max'=>250),
			array('phone_number, account_number, account_title, bank_swift_code, tax_identification_pin, vat_number, contact_person_mobile_number', 'length', 'max'=>100),
			array('contractorid', 'length', 'max'=>30),
			array('contractor_type', 'length', 'max'=>8),
			array('description, create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name, email, address, phone_number, banker, account_number, account_title, bank_swift_code, tax_identification_pin, vat_number, contact_person_name, contact_person_mobile_number, contact_person_email, contractorid, contractor_type, description, create_time, create_user_id, update_time, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'cities' => array(self::MANY_MANY, 'City', 'contractor_catchment(contractor_id, city_id)'),
			'packageForContractors' => array(self::HAS_MANY, 'PackageForContractor', 'contractor_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'email' => 'Email',
			'address' => 'Address',
			'phone_number' => 'Phone Number',
			'banker' => 'Banker',
			'account_number' => 'Account Number',
			'account_title' => 'Account Title',
			'bank_swift_code' => 'Bank Swift Code',
			'tax_identification_pin' => 'Tax Identification Pin',
			'vat_number' => 'Vat Number',
			'contact_person_name' => 'Contact Person Name',
			'contact_person_mobile_number' => 'Contact Person Mobile Number',
			'contact_person_email' => 'Contact Person Email',
			'contractorid' => 'Contractorid',
			'contractor_type' => 'Contractor Type',
			'description' => 'Description',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
			'update_time' => 'Update Time',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('email',$this->email,true);
		$criteria->compare('address',$this->address,true);
		$criteria->compare('phone_number',$this->phone_number,true);
		$criteria->compare('banker',$this->banker,true);
		$criteria->compare('account_number',$this->account_number,true);
		$criteria->compare('account_title',$this->account_title,true);
		$criteria->compare('bank_swift_code',$this->bank_swift_code,true);
		$criteria->compare('tax_identification_pin',$this->tax_identification_pin,true);
		$criteria->compare('vat_number',$this->vat_number,true);
		$criteria->compare('contact_person_name',$this->contact_person_name,true);
		$criteria->compare('contact_person_mobile_number',$this->contact_person_mobile_number,true);
		$criteria->compare('contact_person_email',$this->contact_person_email,true);
		$criteria->compare('contractorid',$this->contractorid,true);
		$criteria->compare('contractor_type',$this->contractor_type,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Contractor the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that generates the contractors id
         */
        public function generateThisContractorID(){
             //get a random number from 1 to 10
                $random_number = $this->generateTheRandomNumber();
                $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
                $day = $today['mday'];
                $month = $today['mon'];
                $contractor_id = "$day$month$random_number";
                return $contractor_id;
        }
        
        
         /**
             * This is the function that generates a random number
             */
            public function generateTheRandomNumber(){
                
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                //generate random numbe from 0 to $today
                $random_number = mt_rand(0,$today);
               return $random_number;
            }
            
            
            
            /**
         * This is the function that list all contractors in the marketplace
         */
        public function listAllContractorsInTheMarketplace(){
            $targets = [];
            $contractors = Contractor::model()->findAll();
            foreach($contractors as $contractor){
                $targets[] = $contractor;
            } 
             
            return  $targets;  
        }
        
         /**
         * This is the function that confirms if a contractor is a delivery contractor
         */
        public function isThisADeliveryContractor($contractor_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('contractor')
                    ->where("id = $contractor_id and contractor_type='courier'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
        /**
         * This is the function that confirms if a contractor is a delivery contractor
         */
        public function isThisAPackagingContractor($contractor_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('contractor')
                    ->where("id = $contractor_id and contractor_type='packager'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            
        }
           
}
