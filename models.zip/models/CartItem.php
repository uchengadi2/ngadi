<?php

/**
 * This is the model class for table "cart_item".
 *
 * The followings are the available columns in table 'cart_item':
 * @property string $id
 * @property string $cart_id
 * @property string $product_id
 * @property integer $pricing_id
 * @property integer $promotion_id
 * @property string $promotion_type
 * @property integer $inventory_id
 * @property double $quantity
 * @property string $date_added
 * @property string $date_updated
 * @property integer $is_a_group_purchase
 * @property integer $group_id
 */
class CartItem extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'cart_item';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('cart_id, product_id', 'required'),
			array('pricing_id, promotion_id, inventory_id, is_a_group_purchase, group_id', 'numerical', 'integerOnly'=>true),
			array('quantity', 'numerical'),
			array('cart_id, product_id', 'length', 'max'=>10),
			array('promotion_type', 'length', 'max'=>250),
			array('date_added, date_updated', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, cart_id, product_id, pricing_id, promotion_id, promotion_type, inventory_id, quantity, date_added, date_updated, is_a_group_purchase, group_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'cart_id' => 'Cart',
			'product_id' => 'Product',
			'pricing_id' => 'Pricing',
			'promotion_id' => 'Promotion',
			'promotion_type' => 'Promotion Type',
			'inventory_id' => 'Inventory',
			'quantity' => 'Quantity',
			'date_added' => 'Date Added',
			'date_updated' => 'Date Updated',
			'is_a_group_purchase' => 'Is A Group Purchase',
			'group_id' => 'Group',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('cart_id',$this->cart_id,true);
		$criteria->compare('product_id',$this->product_id,true);
		$criteria->compare('pricing_id',$this->pricing_id);
		$criteria->compare('promotion_id',$this->promotion_id);
		$criteria->compare('promotion_type',$this->promotion_type,true);
		$criteria->compare('inventory_id',$this->inventory_id);
		$criteria->compare('quantity',$this->quantity);
		$criteria->compare('date_added',$this->date_added,true);
		$criteria->compare('date_updated',$this->date_updated,true);
		$criteria->compare('is_a_group_purchase',$this->is_a_group_purchase);
		$criteria->compare('group_id',$this->group_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return CartItem the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that gets all items in a cart
         */
        public function getAllTheItemsInThisCart($cart_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='cart_id=:cartid';
                $criteria->params = array(':cartid'=>$cart_id);
                $items= CartItem::model()->findAll($criteria);
                
                $data = [];
                
                foreach($items as $item){
                    $data[] = $item['id'];
                }
                return $data;
        }
        
        
        /**
         * This is the function that retrieves the quantity of an item in a cart
         */
        public function getTheQuantityOfThisCartItem($id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $item= CartItem::model()->find($criteria);
                
                return $item['quantity'];
        }
        
        
         /**
         * This is the function that retrieves the cost per unit of an item in a cart
         */
        public function getTheCostPerItemOfThisItem($id){
               $model = new Pricing;
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $item= CartItem::model()->find($criteria);
                
                $price_per_unit = $model->getThePriceOfThisPricingId($item['pricing_id']);
                
                return $price_per_unit;
        }
        
        
         /**
         * This is the function that retrieves the  unit of an item in a cart
         */
        public function getTheUnitOfThisItem($id){
                $model = new Pricing;
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $item= CartItem::model()->find($criteria);
                
                $unit = $model->getTheUnitOfThisPricing($item['pricing_id']);
                
                return $unit;
        }
        
        
        
         /**
         * This is the function that retrieves the  unit of an item in a cart
         */
        public function getThePrimeCustomerDiscountRateOfThisItem($id){
                $model = new Pricing;
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $item= CartItem::model()->find($criteria);
                
                $prime_customer_discount_rate = $model->getThePrimeCustomerDiscountRate($item['pricing_id']);
                
                return $prime_customer_discount_rate;
        }
        
        
        
        /**
         * This is the function that retrieves the measurement type of a cart item
         */
        public function getTheMeasurementTypeOfThisCartItem($id){
            $model = new Pricing;
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $item= CartItem::model()->find($criteria);
            
            $measurement_type = $model->getTheMeasurementTypeOfThisPricing($item['pricing_id']);
            return $measurement_type;
        }
        
        
        /**
         * This is the function that retrieves the warehouse location id of product inventory 
         */
        public function getTheWarehouseLocationOfThisCartItem($id){
            $model = new Pricing;
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $item= CartItem::model()->find($criteria);
            
            $warehouse_location_id = $model->getTheWarehouseLocationIdOfThisPricing($item['pricing_id']);
            return $warehouse_location_id;
        }
        
        
        
        /**
         * This is the function that retrieves the promotional id of an item in a cart
         */
        public function getThePromotionIdOfThisCartItemId($id){
            $model = new CartItem;
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $item= CartItem::model()->find($criteria);
            
            return $item['promotion_id'];
        }
        
        
        /**
         * This is the function that retrieves the pricing id of an item in a cart
         */
        public function getThePricingIdOfThisCartItem($id){
            $model = new CartItem;
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $item= CartItem::model()->find($criteria);
            
            return $item['pricing_id'];
        }
        
       /**
         * This is the function that retrieves the product id of a cart item
         */
        public function getTheProductIdOfThisItem($id){
            $model = new CartItem;
            $model = new CartItem;
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $item= CartItem::model()->find($criteria);
            
            return $item['product_id'];
        }
}
