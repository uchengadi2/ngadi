# ext-theme-neptune-6bfc6c22-9346-4ec0-a618-74538fb2bcf2/resources

This folder contains static resources (typically an `"images"` folder as well).
